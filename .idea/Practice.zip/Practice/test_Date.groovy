import java.text.DateFormat
import java.text.SimpleDateFormat

//def l_LastDayWorked =  '2019-09-11T11:14:25'
//DateFormat srcDf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//Date date1 = srcDf1.parse(l_LastDayWorked)
//def date = Date.parse(srcDf1, l_LastDayWorked)
//println(date)
//
//String in_date='2020-08-11T11:14:25.0000000-4:00'
//String outDate
//if (in_date.size() != 0){
//    in_date = in_date.substring(0,19)
//    Date date = Date.parse("yyyy-MM-dd'T'HH:mm:ss",in_date)
//    outDate = date.format( 'yyyyMMdd' )
//
//}
//else {
//    outDate = ''
//}
//
//println(outDate)

//    var1 = '2019-09-11T11:14:25.00000'
//    in_date = var1.substring(0,19);
//    String D=in_date;
//    DateFormat converter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//    Date dt = (Date) converter.parse(D);
//    DateFormat converter1 = new SimpleDateFormat("yyyyMMdd");
//    outDate = converter1.format(dt);
//    return  outDate;
//
//
//
//println(outDate);

//String identifier = "UD,CD"
//String manifacture = "U01M"
//String distribution =
//def fld_INV_ITEM_GROUP = "DGH"
//
//if (fld_INV_ITEM_GROUP == "DGH"){
//    String plantFirstChar = sval.take(1)
//    String plantLastChar = sval.reverse().take(1)
//    identifier
//}


//String var1 = "PA201"
//String Code = ""
//if (var1.take(1) == "U"){
//    Code  = "US20"
//} else if(var1.take(1) == "C"){
//    Code  = "CA20"
//} else {
//    Code =""
//}
//
//println(Code)

def Emplyee = '1002'
def punchdate  = '10-Apr-2020'
// call: -  get  employeeType and workschedle patter for 1003 where empJob effective on 10-Apr-2020
if (employeeType = 'punchOutOnly'){
    //if employee worked before scheduled start time then consider that hours overTime time type.
    // then take the scheduled end time from work pattern  as Timesheet "end time"
    // example:
    // scheduled work start time 8.30AM, end time 4.30PM, if puncIn comes at 7.30 then, overtime = 1hrd, start time =8.30, end time = 4.30
}
else if (employeeType = 'punchInOnly')
{

}
else if (employeeType = 'normal employee' && pair = 'yes')
{
    //send to Employee time sheet
}

else if (employeeType = 'normal employee' && pair = 'no')
{
    //send to custom time sheet
}