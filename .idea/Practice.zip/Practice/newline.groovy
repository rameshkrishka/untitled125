char lfchar = 10
char nullcar=   00
def a = 'welcome'
def b = 'ramesh'
def c = 'to the team'
print(a+nullcar+lfchar+b+lfchar+c+lfchar)
