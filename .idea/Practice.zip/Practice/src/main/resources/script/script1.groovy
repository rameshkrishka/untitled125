String a  ='DGH'
String b = 'U00M'
String c = 'C00D'

def cd = c.matches(".*[CD].*")
println(cd)
if (a == 'DGH' && (b.matches(".*[UM].*") || b.matches(".*[CD].*"))){
    println('Hi')
}
else {
    println('no')
}