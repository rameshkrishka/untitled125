import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil

def body               = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\education_batchUpsert_delete.xml')
def responseBody        = new XmlSlurper().parse(body)
def writter =  new StringWriter()
def builder = new MarkupBuilder(writter)

print("hi")
responseBody.children().groupBy{it.userId.toString()}.each{  group,  recs->
//    XmlUtil.serialize(recs)
println(group)
//    group.toList().each{ r->
//        println(key)
            builder.batchChangeSet{
                println('hi')
            batchChangeSetPart{
                r.eachWithIndex{ key,val ->
                    batchChangeSetPart(XmlUtil.serialize(key).toString().replaceAll("<\\?xml.*\\?>", "").replaceAll(" &lt;","<").replaceAll("&gt;",""))
//                }
//                println(key)
//                user(r.userId.text())
//                println(key)
//            XmlUtil.serialize(recs)
//                "$key"(val)
//                batchChangeSetPart(XmlUtil.serialize(recs).toString())
//                recs.eachWithIndex{ key,val->
//                    "$key"(val)
//                }
            }
        }
    }

//}

println(writter.toString())
//responseBody.batchChangeSetPart.each{ r ->
//    println(r.userId)
//
}