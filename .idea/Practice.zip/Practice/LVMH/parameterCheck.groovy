import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.groovy.json.internal.LazyMap

File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\company.json')

def mandatoryFieldsFOCompany = ['externalCode','startDate','endDate','name','status','currency','country','cust_ESSAccess']
def mandatoryParameters = ['maisonName','callbackEndpoint','callbackAuthType','sfProxyEndpoint','sfProxyAuthType','emPayload','uuid']
def uuid ='123'
def responseBody    = new JsonSlurper().parse(sampleFile)
def validRecord     = []
def invalidRecord   = []
def response        = []
def entityName                  = 'Background_Education'


responseBody."$entityName".each {  r ->
    println(r)
    response.add([groupCode:"",subsidiaryCode:r.subsidiaryEmployeeID,status:"failed",description:"Mandatory parameter   missing"])
}


response        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"failed",totalRecords:responseBody."$entityName"."$entityName".size(),processed:'0',failed:responseBody."$entityName"."$entityName".size(),messageLog:response]])
println(response)