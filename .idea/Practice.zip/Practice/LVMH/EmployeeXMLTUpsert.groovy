import groovy.xml.MarkupBuilder


//class employeeUpsert {
//
//    static void main(String[] args) {

        def data = new File("C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/Employee.xml").getText("UTF-8")
        def stringWriter = new StringWriter()
        def employeeBatchBuild = new MarkupBuilder(stringWriter)
        def queryPosition = new StringWriter()

        def parser = new XmlSlurper().parseText(data)

        employeeBatchBuild.batchParts {
            parser.Employee.each { def eachEmployee ->

                batchChangeSet {

                    def subsidiaryEmployeeID = eachEmployee.person.person_id_external.text()
                    def subsidiaryUserId = eachEmployee.person.logon_user_id.text()
                    def groupEmployeeID = eachEmployee.custom_string1.text()

                    def newEmployee = false
                    def userNodeCreated = false
                    def jobInfoStore = []
                    def jobInfoActionStore = []


                    if (eachEmployee.person.action.text().equalsIgnoreCase("INSERT"))
                        newEmployee = true


                    /**
                     *
                     * START --- Implementation for User & PerPerson Portlet
                     *
                     */

                    if (!eachEmployee.person.action.text().equalsIgnoreCase("NO CHANGE") && !userNodeCreated) {

                        userNodeCreated = true
                        batchChangeSetPart {
                            method('UPSERT')
                            User {
                                User {
                                    "userId"("{{sfID}}")
                                    "status"("Active")
                                    "empId"("{{empID}}")

                                    eachEmployee.person.personal_information.each { def personalInfo ->

                                        personalInfo.childNodes().each { def eachPersonalInfoNode ->

                                            println eachPersonalInfoNode.name() + '---' + eachPersonalInfoNode.getClass()

                                            def lookup_EachPersonalInfoNode = eachPersonalInfoNode.name()
                                            def nodeValue = eachPersonalInfoNode.text()

                                            if (lookup_EachPersonalInfoNode.equalsIgnoreCase("first_name") || lookup_EachPersonalInfoNode.equalsIgnoreCase("last_name") || lookup_EachPersonalInfoNode.equalsIgnoreCase("custom_date1"))
                                                "$lookup_EachPersonalInfoNode"("$nodeValue")

                                        }

                                    }


                                }
                            }
                        }

                        if (eachEmployee.person.action.text().equalsIgnoreCase('INSERT')) {
                            batchChangeSetPart {
                                method('UPSERT')
                                PerPerson {
                                    PerPerson {
                                        "personIdExternal"('{{sfID}}')
                                        "userId"('{{sfID}}')
                                        "customString1"("{{empID}}")
                                    }
                                }
                            }
                        }

                    }


                    /**
                     *
                     * END  ---  Implementation for User & PerPerson Portlet
                     *
                     */


                    /**
                     *
                     * START --- Implementation for PerPersonal Portlet
                     *
                     */

                    eachEmployee.person.personal_information.each { def personalInfo ->

                        if (!personalInfo.action.text().equalsIgnoreCase("NO CHANGE")) {

                            batchChangeSetPart {
                                method('UPSERT')
                                PerPersonal {
                                    PerPersonal {
                                        personalInfo.childNodes().each { def eachPersonalInfoNode ->
                                            if (eachPersonalInfoNode.childNodes().size() == 0) {
                                                println eachPersonalInfoNode.name() + '---' + eachPersonalInfoNode.getClass()
                                                println eachPersonalInfoNode.childNodes().size()

                                                def lookup_EachPersonalInfoNode = eachPersonalInfoNode.name()
                                                def nodeValue = eachPersonalInfoNode.text()
                                                if (lookup_EachPersonalInfoNode != null && !lookup_EachPersonalInfoNode.isEmpty())
                                                    "$lookup_EachPersonalInfoNode"("$nodeValue")
                                            }

                                        }
                                    }
                                }
                            }
                        }

                    }


                    /**
                     *
                     * END  ---  Implementation for PerPersonal Portlet
                     *
                     */

                    eachEmployee.person.phone_information.each { def phoneInfo ->

                        if (!phoneInfo.action.text().equalsIgnoreCase("NO CHANGE")) {

                            batchChangeSetPart {
                                method('UPSERT')
                                PerPhone {
                                    PerPhone {
                                        phoneInfo.childNodes().each { def eachPhonefoNode ->

                                            if (eachPhonefoNode.childNodes().size() == 0) {
                                                println eachPhonefoNode.name() + '---' + eachPhonefoNode.getClass()
                                                println eachPhonefoNode.childNodes().size()
                                                def lookup_EachPhoneInfoNode = eachPhonefoNode.name()
                                                def nodeValue = eachPhonefoNode.text()
                                                if (lookup_EachPhoneInfoNode != null && !lookup_EachPhoneInfoNode.isEmpty())
                                                    "$lookup_EachPhoneInfoNode"("$nodeValue")
                                            }

                                        }
                                    }
                                }
                            }
                        }

                    }

                    eachEmployee.person.phone_information.each { def emailInfo ->

                        if (!emailInfo.action.text().equalsIgnoreCase("NO CHANGE")) {

                            batchChangeSetPart {
                                method('UPSERT')
                                PerEmail {
                                    PerEmail {
                                        emailInfo.childNodes().each { def eachEmailInfoNode ->

                                            if (eachEmailInfoNode.childNodes().size() == 0) {
                                                println eachEmailInfoNode.name() + '---' + eachEmailInfoNode.getClass()
                                                println eachEmailInfoNode.childNodes().size()

                                                def lookup_EachEmailInfoNode = eachEmailInfoNode.name()
                                                def nodeValue = eachEmailInfoNode.text()
                                                if (lookup_EachEmailInfoNode != null && !lookup_EachEmailInfoNode.isEmpty())
                                                    "$lookup_EachEmailInfoNode"("$nodeValue")
                                            }

                                        }
                                    }
                                }
                            }
                        }

                    }





                    /**
                     *
                     * START --- Implementation for EmpEmployment
                     *
                     */


                    eachEmployee.person.employment_information.each { def employmentInfo ->

                        if (!employmentInfo.action.text().equalsIgnoreCase("NO CHANGE")) {


                            batchChangeSetPart {
                                method('UPSERT')
                                EmpEmployment {
                                    EmpEmployment {
                                        "personIdExternal"('{{sfID}}')
                                        "userId"('{{sfID}}')

                                        employmentInfo.childNodes().each { def eachEmploymentInfoNode ->


                                            if (eachEmploymentInfoNode.childNodes().size() == 0) {

                                                def lookup_EachEmploymentInfoNode = eachEmploymentInfoNode.name()
                                                def nodeValue = eachEmploymentInfoNode.text()
                                                if (lookup_EachEmploymentInfoNode != null && !lookup_EachEmploymentInfoNode.isEmpty())
                                                    "$lookup_EachEmploymentInfoNode"("$nodeValue")

                                            }

                                            if (eachEmploymentInfoNode.childNodes().size() > 0) {

                                                if (eachEmploymentInfoNode.name().equalsIgnoreCase("job_information")) {
                                                    jobInfoStore.add(eachEmploymentInfoNode)
                                                }

                                                if (eachEmploymentInfoNode.name().equalsIgnoreCase("job_event_information")) {
                                                    jobInfoActionStore.add(eachEmploymentInfoNode)
                                                }


                                            }

                                        }

                                    }
                                }
                            }

                        } else {
                            employmentInfo.childNodes().each { def eachEmploymentInfoNode ->

                                if (eachEmploymentInfoNode.childNodes().size() > 0) {

                                    if (eachEmploymentInfoNode.name().equalsIgnoreCase("job_information")) {
                                        jobInfoStore.add(eachEmploymentInfoNode)
                                    }

                                    if (eachEmploymentInfoNode.name().equalsIgnoreCase("job_event_information")) {
                                        jobInfoActionStore.add(eachEmploymentInfoNode)
                                    }


                                }
                            }
                        }

                    }


                    /**
                     *
                     * END --- Implementation for EmpEmployment
                     *
                     */


                    /**
                     *
                     * START --- Implementation for Job Information Portlet
                     *
                     */

                    jobInfoStore.each { def eachJobInfo ->


                        def actionMapper = [:]
                        jobInfoActionStore.each { def eachEventSegment ->
                            def actionEvent = ''
                            def startDateEvent = ''
                            def eventReason = ''
                            eachEventSegment.childNodes().each { def eachEvent ->
                                if (eachEvent.name() == 'action')
                                    actionEvent = eachEvent.text()


                                if (eachEvent.name() == 'event_date')
                                    startDateEvent = eachEvent.text()

                                if (eachEvent.name() == 'event_reason')
                                    eventReason = eachEvent.text()

                            }

                            if (actionEvent.equalsIgnoreCase("INSERT") || actionEvent.equalsIgnoreCase("CHANGE")) {
                                if (actionMapper.get(startDateEvent) == null || (actionMapper.get(startDateEvent) != null && !actionMapper.get(startDateEvent).equalsIgnoreCase("HIRE")) || (actionMapper.get(startDateEvent) != null && !actionMapper.get(startDateEvent).equalsIgnoreCase("REHI")) || (actionMapper.get(startDateEvent) != null && !actionMapper.get(startDateEvent).equalsIgnoreCase("TERMINATION")))
                                    actionMapper.put(startDateEvent, "$eventReason")
                            }
                        }


                        def jobInfoAction = 'NO CHANGE'
                        eachJobInfo.childNodes().each { def eachJobInfoNodeForAction ->
                            if (eachJobInfoNodeForAction.name().equalsIgnoreCase("action"))
                                jobInfoAction = eachJobInfoNodeForAction.text()
                        }


                        println actionMapper.toString()

                        if (!jobInfoAction.equalsIgnoreCase("NO CHANGE")) {
                            batchChangeSetPart {
                                method('UPSERT')
                                EmpJob {
                                    EmpJob {
                                        "userId"('{{sfID}}')
                                        eachJobInfo.childNodes().each { def eachJobInfoNode ->
                                            def lookup_EachJobInfoNode = eachJobInfoNode.name()
                                            def nodeValue = eachJobInfoNode.text()
                                            if (lookup_EachJobInfoNode != null && !lookup_EachJobInfoNode.isEmpty() && !lookup_EachJobInfoNode.equalsIgnoreCase("eventReason")) {
                                                if (lookup_EachJobInfoNode.equalsIgnoreCase("startDate")) {
                                                    def getEventReason = actionMapper.get(nodeValue)
                                                    "eventReason"(getEventReason)
                                                } else {
                                                    if (lookup_EachJobInfoNode.equalsIgnoreCase("position")) {
                                                        if (queryPosition.toString().isEmpty())
                                                            queryPosition.append("cust_IDComp eq '${nodeValue}'")
                                                        else
                                                            queryPosition.append(" or cust_IDComp eq '${nodeValue}'")

                                                    } else
                                                        "$lookup_EachJobInfoNode"("$nodeValue")
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }


                    /**
                     *
                     * END --- Implementation for Job Information Portlet
                     *
                     */


                }


            }
        }

        println stringWriter.toString()

        println(queryPosition.toString())

//
//    }
//}
