import java.text.SimpleDateFormat;
import java.text.DateFormat;

//String newtimeZone = TimeZone.getTimeZone("EST");
//def ESTCurrentDateTime = Date.format("yyyy-MM-dd'T'HH:mm:ss", newtimeZone);
//def ESTCurrentDate = new Date().format("yyyy-MM-dd", newtimeZone);
//def ESTfiletime = new Date().format("yyyyMMdd-HHmmss", newtimeZone );
//
//println(ESTCurrentDateTime)

def dateIn = "2022-02-12T20:47:06.906"

DateFormat srcDf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
Date date1 = srcDf1.parse(dateIn).plus(10)

String formateDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").format(date1);
//ESTfiletime = new Date().format("yyyyMMdd-HHmmss", date1 );
//DateFormat srcDf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
//Date date2 = srcDf2.parse(date1)

println(formateDate)
def increaseDate = '10'
def date = new Date().plus(10).format("yyyy-MM-dd'T'HH:mm:ss.S")//+increaseDate.toInteger()

//println(date)