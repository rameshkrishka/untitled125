import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.groovy.json.internal.LazyMap

File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\educationLis.json')

//def mandatoryFieldsFOCompany = ['startDate','endDate','name','status','currency','country','cust_ESSAccess']
def mandatoryField             = ['userId','educationYear','country','school']
def uuid                    = "AGDiykxNMjS9gEOWil19irJKnlNr"
def responseBody            = new JsonSlurper().parse(sampleFile)
def validRecord             = []
def invalidRecord           = []
def response                = []
def maisonName
def callbackEndpoint
def callbackType
def callbackAuthType
def sfProxyEndpoint
def sfProxyAuthType
def emPayload
def entityName = "Background_Education"
def validUsers                  = []
def inValidUsers                = []
def allUsers                    = []
def totalRecords                = 0
def processingResponse          = []
def failedResponse              = [:]


responseBody."$entityName"."$entityName".each {  r ->
    totalRecords = totalRecords+1
    allUsers.add(r.userId)
    def deletionFlag  = false
    if(r.containsKey("country") == false && r.containsKey("partnership") == false && r.containsKey("major")== false && r.containsKey("school") == false && r.containsKey("degree") == false && r.containsKey("bgOrderPos") == false && r.containsKey("backgroundElementId") == false && r.containsKey("educationYear") == false){
        println(r.userId)
        response.add([groupCode:"",subsidiaryCode:r.userId,backgroundElementId:r.backgroundElementId,status:"processing",description:"processing"])
        deletionFlag = true
    }

    else if (checkFieldValueExist(mandatoryField,r).size() == 0 && deletionFlag == false) {
        validUsers.add(r.userId)
        response.add([groupCode:"",subsidiaryCode:r.userId,backgroundElementId:r.backgroundElementId,status:"processing",description:"processing"])
    }
    else  {
        def missingFieldList = checkFieldValueExist(mandatoryField,r).toString()
        invalidRecord.add(r)
        inValidUsers.add(r.userId)
        response.add([groupCode:"",subsidiaryCode:r.userId,backgroundElementId:r.backgroundElementId,status:"failed",description:"Mandatory field "+missingFieldList+" missing"])
        failedResponse.put(r.userId,"Mandatory field"+missingFieldList.toString().replaceAll("\\[", " ").replaceAll("]"," ")+" missing")
    }
}

response.each{ eachResponse ->

    println(eachResponse.subsidiaryCode)
}

//println(failedResponse)
//println(response)
//responseBody."$entityName"."$entityName".each{ r ->
//    userId = r.userId
//    if(inValidUsers.contains(r.userId) == false){
//        validRecord.add(r)
//    }
//}

//responseBody."$entityName"."$entityName".each {  r ->
//    totalRecords = totalRecords+1
//    allUsers.add(r.userId)
//    if ( r.data == []){
//        validUsers.add(r.groupEmployeeID)
//        response.add([groupCode:"",subsidiaryCode:r.groupEmployeeID,backgroundElementId:"",status:"processing",description:"processing"])
//    }
//
//    r.data.each{ eachList ->
//        if (checkFieldValueExist(mandatoryFieldsFOCompany,eachList).size() == 0 ) {
//            validUsers.add(r.groupEmployeeID)
//            response.add([groupCode:"",subsidiaryCode:r.groupEmployeeID,backgroundElementId:eachList.backgroundElementId,status:"processing",description:"processing"])
//        }
//        else {
//            def missingFieldList = checkFieldValueExist(mandatoryFieldsFOCompany,eachList).toString()
//            invalidRecord.add(r)
//            inValidUsers.add(r.groupEmployeeID)
//            response.add([groupCode:"",subsidiaryCode:r.groupEmployeeID,backgroundElementId:eachList.backgroundElementId,status:"failed",description:"Mandatory field "+missingFieldList+" missing"])
//        }
//    }
//}

responseBody."$entityName"."$entityName".each{ r ->
    userId = r.userId
    if(inValidUsers.contains(r.userId) == false){
        validRecord.add(r)
    }
}


validRecords    = validRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":validRecord]]):""
invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":invalidRecord]]):""
responseMessage        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]])
//response_EM     = [FOCompany:[uuid:uuid,status:"processing",totalRecords:responseBody.FOCompany.FOCompany.size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]]

def date                                = new Date().format("yyyy-MM-dd'T'HH:mm:ss.S")      /** Parameter for EMEvent DateTime**/
def ID                                  = new Date().format("yyyyMMddHHmmssS")              /** Parameter for payload ID**/
def fileName_EM                         = uuid+".xml"                    /** File name **/

def startEMMonitoredProcess             = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def startEMEventAttribute               = [EMEventAttribute:["name":"Details","value":"iFlow Processing Started"]]
def EMeventStart                        = ["process":startEMMonitoredProcess,"eventAttributes":startEMEventAttribute,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow Start","eventType":"START"]

def errorEMMonitoredProcess               = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def errorEMEventAttribute                 = [EMEventAttribute:["name":"Details","value":"iFlow Processing Ends"]]
def errorEMEventPayload                   = [EMEventPayload:["id":ID,"fileName":fileName_EM,"fileType":"xml","payload":responseMessage.bytes.encodeBase64().toString(),"mimeType":"text/xml","type":"XML"]]
def EMeventError                          = ["process":errorEMMonitoredProcess,"eventAttributes":errorEMEventAttribute,eventPayload:errorEMEventPayload,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow End","eventType":"ERROR"]

def endEMMonitoredProcess               = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def endEMEventAttribute                 = [EMEventAttribute:["name":"Details","value":"iFlow Processing Ends"]]
def endEMEventPayload                   = [EMEventPayload:["id":ID,"fileName":"$fileName_EM","fileType":"xml","payload":responseMessage.bytes.encodeBase64().toString(),"mimeType":"text/xml","type":"XML"]]
def EMeventEnd                          = ["process":endEMMonitoredProcess,"eventAttributes":endEMEventAttribute,"eventPayload":endEMEventPayload,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow End","eventType":"END"]

def combineEvent
if (invalidRecord.size()>0){
    combineEvent                        = [EMeventStart,EMeventError,EMeventEnd]
}else{
    combineEvent                        = [EMeventStart,EMeventEnd]
}

def events                              = [EMEvent:combineEvent]

response_EM            = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response,EMEvent:events]])

println(response_EM)


def checkFieldValueExist(List field, segment){
    def missedFields = []
    field.each { f  ->
        def getfieldValue = segment.get(f)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}


//
//println("response\n"+response)
//println("validRecords\n"+validRecords)
//println("invalidRecords\n"+invalidRecords)


//println("valid"+validRecord)
//println("invlaid"+invalidRecord)

//org.apache.groovy.json.internal.LazyMap
//def checkFieldExist(List field, segment){
//    def fieldNotExistFlag = ''
//    field.each {   f  ->
//        def exist = segment.containsKey(f)
//        if(exist == false){
//            fieldNotExistFlag = 'Y'
//        }
//    }
//    return  fieldNotExistFlag
//}