import groovy.json.JsonOutput
import groovy.json.JsonSlurper
File body                   = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\company.json')
def  response               = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/response.xml')

def upsertRequest           = new JsonSlurper().parse(body)
def upsertResponse          = new XmlSlurper().parse(response)
def upsertRequestMap        = [:]
def upsertRequestToJMSMap   = []
def entityName              = "FOCompany"
def responseSegmentName     = "$entityName"+"UpsertResponse"

/** Process each segment to map**/
upsertRequest."$entityName"."$entityName".each{ r ->
    def externalCode = r.externalCode
    upsertRequestMap.put(externalCode,r)
}

def listOfValidation  = ["Invalid reference for valid when association cust_ParentCompanyAssociation","Invalid reference for valid when association test"," Picklist value is wrong"]
def respaonseMessage = "Invalid reference '(effectiveStartDate=1900-01-01, externalCode=PC_033_Test)' for valid when association 'cust_ParentCompanyAssociation'."
def a= respaonseMessage.mat("Invalid reference for valid when association cust_ParentCompanyAssociation")
println(a)


upsertResponse."$responseSegmentName".each { eachLine ->
        if(eachLine.status == 'ERROR'){
            def message = eachLine.message.text()
            def externalCode = eachLine.key.toString().split('=').getAt(1).toString().split(',').getAt(0).toString()
            if(message.startsWith("Invalid reference")){
                upsertRequestToJMSMap.add(upsertRequestMap.get(externalCode))
            }
        }
}


if (upsertRequestToJMSMap.size() >0){
    def failedPayloadToJMS = JsonOutput.toJson(FOCompany:[FOCompany:upsertRequestToJMSMap])
} else{
    failedPayloadToJMS = ''
}


println(failedPayloadToJMS)