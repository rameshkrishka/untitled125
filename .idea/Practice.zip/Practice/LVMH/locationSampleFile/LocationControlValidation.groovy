
def code = "LOC_0001 [E67]"
def validationFormat
def formatFailedErrorMessage
def subCode =''
validationFormat = code.contains("_") && code.contains("[") && code.contains("]")  ? true : false
println(validationFormat)

if (validationFormat == true){
    subCode = code.split('_').getAt(1).toString().split('\\[').getAt(0).toString().replaceAll("[^a-zA-Z0-9]+", "")
}

println(subCode)


