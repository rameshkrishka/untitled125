

def  response               = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/paretCompayCheck.xml')
def lookupParse       =  new XmlSlurper().parse(response) // parse get response

p_externalCode = "LOC_ZZ01 [ZZ1]"
/** ExternalCode control **/
def externalCodeControlFlag
validationFormat            = p_externalCode.toString().contains("_") && p_externalCode.toString().contains("[") && p_externalCode.toString().contains("]")  ? true : false
validationFormat            == false ? println('Enter right Location code format : CC_<6 Digits Code> [<subsidiary Id>] '):''
def subCode                 = ''
if (validationFormat == true){
    subCode = p_externalCode.split('_').getAt(1).toString().split('\\[').getAt(0).toString().replaceAll("[^a-zA-Z0-9]+", "")
}
println(subCode.size())
if (subCode.size() == 4){
    externalCodeControlFlag = true
} else{
    externalCodeControlFlag = false
   println('Enter right Location code format : CC_<6 Digits Code> [<subsidiary Id>] ')
}
println("externalCodeControlFlag"+  externalCodeControlFlag)
/** subsidiary  association check **/
def subsidiaryExternalCodeCheckFlag
def externalCodeExtract         =lookupParse.FOLocation.externalCode.text().toString().find(/\[(.*?)]/).toString().replaceAll("[^a-zA-Z0-9 ]+","")
println(externalCodeExtract)
def departmentAssociateExtarct  = lookupParse.FOLocation.companyFlx.text()//.toString().find(/\[(.*?)]/).toString().replaceAll("[^a-zA-Z0-9 ]+","")
println(departmentAssociateExtarct)
if (externalCodeExtract == departmentAssociateExtarct){
    subsidiaryExternalCodeCheckFlag = true
}else{
    subsidiaryExternalCodeCheckFlag = false
    println("Failed: Subsidiary externalCode of associated Department is not same than the one in CostCenter code suffix")
}
println(subsidiaryExternalCodeCheckFlag)

//parentCompany = responseParse.FOLocation.companyFlx.toString()
//parentCompanyCheckFlag = responseParse.FOLocation.externalCode.text().toString()//.toString().contains( responseParse.FOLocation.companyFlx.toString()) == true ? true:false
//println(parentCompanyCheckFlag)
//
//def a = parentCompanyCheckFlag.find(/\[(.*?)]/).toString().replaceAll("[^a-zA-Z0-9 ]+","")
//
//flag = responseParse.FOLocation.companyFlx.toString() == responseParse.FOLocation.externalCode.text().toString().find(/\[(.*?)]/).toString().replaceAll("[^a-zA-Z0-9 ]+","")?true:false
//println(flag)
//def a = companyInExternalCode."(?<=_)[^._]*(?=\.)"
////println(a)
//externalCodeBefore = companyInExternalCode.indexOf("[")+1
//externalCodeAfter  = companyInExternalCode.indexOf("]")
//
//def output = companyInExternalCode.substring(externalCodeBefore,externalCodeAfter)
//
////println(parentCompany)
////println(companyInExternalCode)
////println(output)
//StringUtils.substringBetween(parentCompanyCheckFlag, "[", "]");

//parentCompanyCheckFlag.toString().takeBetween( '[', ']' )
//
//public static CharSequence takeBetween(CharSequence "well[cm]", CharSequence "[", CharSequence "]")
//
//println CharSequence