import groovy.json.JsonSlurper
println("ji")
import groovy.xml.XmlUtil;


File sampleFile = new File('C:\\Users\\I524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\Photo.xml')
//def photo    = new JsonSlurper().parse(sampleFile)
def photo         =  new XmlSlurper().parse(sampleFile)
def vaidPhotoTypeCheckFlag = false
//C:\Users\I524259\OneDrive - SAP SE\Practice\LVMH\locationSampleFile\Photo.xml
photo.Photo.each{ r ->
    if (r.photoType == '1' && r.width =='180' && r.height =='240'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '2' && r.width =='20' && r.height =='27'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '3' && r.width =='60' && r.height =='80'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '7' && r.width =='45' && r.height =='60'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '26' && r.width =='60' && r.height =='60'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '27' && r.width =='30' && r.height =='30'){
        vaidPhotoTypeCheckFlag = true
    }else if (r.photoType == '14' && r.width =='980' && r.height =='580'){
        vaidPhotoTypeCheckFlag = true
    }else{
        vaidPhotoTypeCheckFlag = false
    }
    r.height.replaceNode { }
//    r.remove(r.width)
}

//photo.Photo.remove(photo.Photo.width)
//photo.Photo.height =''
println( XmlUtil.serialize(photo))
println(vaidPhotoTypeCheckFlag)