import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import groovy.util.Node;
import groovy.util.XmlNodePrinter
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput
import java.util.HashMap;

File body = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\education_upsert_response.xml')



def uuid            = "AGDiykxNMjS9gEOWil19irJKnlNr8"



                         /** Get body **/
def responseBody        = new XmlSlurper().parse(body)                  /** Get actual body **/
def successRecord       = []                                                /** Parameter to store success records **/
def errordRecord        = []                                                /** Parameter to store error records **/
def response            = []                                                /** Parameter to store response records **/
def entityName          = 'Background_Education'                                       /** Response root segment name **/
def writter             = new StringWriter()                                /** XML writter **/
def builder             = new MarkupBuilder(writter)                        /** XML Builder **/
def ID                  = new Date().format("yyyyMMddHHmmssS")              /** Parameter for payload ID**/
def date                = new Date().format("yyyy-MM-dd'T'HH:mm:ss.S")      /** Parameter for EMEvent DateTime**/
emPayload               = 'true'                        /** Get emPayload flag **/
def JMSRetries          = '0'                    /** Get retry count */
def fileName_EM         = uuid+".xml"                    /** File name **/
// def startDate           = map.get("effectiveStartDate").toString().substring(0,10)
def totalRecords        = 5
def invalidRecords      = 0
def inactiveSubsidiaryIDs = [12,1212]
def status

responseBody.batchChangeSetResponse.each { r ->
    r.batchChangeSetPartResponse.statusCode.text().startsWith("2") == true?successRecord.add(r.batchChangeSetPartResponse.statusCode.text()):errordRecord.add(r.batchChangeSetPartResponse.statusCode.text())
}
println("successRecord"+successRecord)
println("errordRecord "+ errordRecord )
/** Building JSON Respone body  **/

    def description
    if(successRecord.size() == errordRecord.size()){
        status = "Failed with Error"
        description = responseBody.bytes.encodeBase64().toString()
    }else if(invalidRecords >0 ){
        status = "Failed with Warning"
        description = "Failed with Warning"
    }else{
        status = "Completed"
        description = "Completed"
    }
    response.add([status:status,description:description])

println(response)
def startEMMonitoredProcess
def startEMEventAttribute
def EMeventStart
def startEMEventPayload
def endEMMonitoredProcess
def endEMEventAttribute
def endEMEventPayload
def EMeventEnd
def EMeventError

/** EMEvent Xml for Upsert**/

builder.batchParts{
    batchChangeSet{
        batchChangeSetPart{
            method("UPSERT")
            EMEvent {
                EMEvent {
                    startEMMonitoredProcess     = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
                    startEMEventAttribute       = [EMEventAttribute:["name":"Details","value":"Object Import started"]]
                    EMeventStart                = ["process":startEMMonitoredProcess,"eventAttributes":startEMEventAttribute,"eventDescription":"$uuid - Attempt $JMSRetries","eventTime":date,"eventName":"Object Import started","eventType":"START"]
                    process {
                        EMMonitoredProcess {
                            processDefinitionId("CloudIntegration")
                            processDefinitionName("Replicate $entityName Data to Group Instance")
                            processType("INTEGRATION")
                            processInstanceId(uuid)
                            processInstanceName(uuid)
                        }
                    }
                    eventAttributes {
                        EMEventAttribute {
                            name("Details")
                            value("Object Import started")
                        }
                    }
                    eventDescription("$uuid - Attempt $JMSRetries")
                    eventTime(date)
                    eventName("Object Import started")
                    eventType("START")
                }
            }
        }
        if (errordRecord.size() > 0 || invalidRecords != 0){
            batchChangeSetPart{
                method("UPSERT")
                EMEvent{
                    EMEvent {
                        def errorEMMonitoredProcess       = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid,"hasErrors":"true"]]
                        def errorEMEventAttribute
                        if (invalidRecords != 0){
                            errorEMEventAttribute         = [EMEventAttribute:[["name":"Details","value":"Error during import, Please download the report for more details or contact technical team for more details with uuid - $uuid"],["name":"InactiveUsers","value":"Inactive user List $inactiveSubsidiaryIDs"]]]
                        }else{
                            errorEMEventAttribute         = [EMEventAttribute:["name":"Details","value":"Error during import, Please download the report for more details or contact technical team for more details with uuid - $uuid"]]
                        }
                        errorEMEventPayload           = [EMEventPayload:["id":ID,"fileName":fileName_EM,"fileType":"xml","payload":body.bytes.encodeBase64().toString(),"mimeType":"text/xml","type":"XML"]]
                        EMeventError                = ["process":errorEMMonitoredProcess,"eventAttributes":errorEMEventAttribute,"eventPayload":errorEMEventPayload,"eventDescription":"$uuid - Attempt $JMSRetries","eventTime":date,"eventName":"Object could not be imported","eventType":"ERROR"]
                        process {
                            EMMonitoredProcess {
                                processDefinitionId("CloudIntegration")
                                processDefinitionName("Replicate $entityName Data to Group Instance")
                                processType("INTEGRATION")
                                processInstanceId(uuid)
                                processInstanceName(uuid)
                                hasErrors("true")
                            }
                        }
                        eventAttributes {
                            EMEventAttribute {
                                name("Details")
                                value("Error during import, Please download the report for more details or contact technical team for more details with uuid - $uuid")
                            }
                            if (invalidRecords != 0){
                                EMEventAttribute {
                                    name("InactiveUsers")
                                    value("Inactive user List $inactiveSubsidiaryIDs")
                                }
                            }
                        }
                        eventPayload {
                            EMEventPayload {
                                id(ID)
                                fileName(fileName_EM)
                                fileType("xml")
                                payload(body.bytes.encodeBase64().toString())
                                mimeType("text/xml")
                                type("XML")

                            }
                        }
                        eventDescription("$uuid - Attempt $JMSRetries")
                        eventTime(date)
                        eventName("Object could not be imported")
                        eventType("ERROR")
                    }
                }
            }
        }
        batchChangeSetPart{
            method("UPSERT")
            EMEvent{
                EMEvent {
                    def endEventMessage
                    if (errordRecord.size() >0){
                        endEventMessage = "Object could not be imported"

                    }else{
                        endEventMessage = "Object imported"
                    }
                    endEMMonitoredProcess     = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
                    endEMEventAttribute       = [EMEventAttribute:["name":"Details","value":endEventMessage]]
                    EMeventEnd                = ["process":endEMMonitoredProcess,"eventAttributes":endEMEventAttribute,"eventDescription":"$uuid - Attempt $JMSRetries","eventTime":date,"eventName":endEventMessage,"eventType":"END"]
                    process {
                        EMMonitoredProcess {
                            processDefinitionId("CloudIntegration")
                            processDefinitionName("Replicate $entityName Data to Group Instance")
                            processType("INTEGRATION")
                            processInstanceId(uuid)
                            processInstanceName(uuid)
                        }
                    }
                    eventAttributes {
                        EMEventAttribute {
                            name("Details")
                            value(endEventMessage)
                        }
                    }

                    eventDescription("$uuid - Attempt $JMSRetries")
                    eventTime(date)
                    eventName(endEventMessage)
                    eventType("END")
                }
            }
        }
    }

}


def batchChangeSetPartStart             = [method:"UPSERT",EMEvent:[EMEvent:EMeventStart]]
def batchChangeSetPartError             = [method:"UPSERT",EMEvent:[EMEvent:EMeventError]]
def batchChangeSetPartEnd               = [method:"UPSERT",EMEvent:[EMEvent:EMeventEnd]]

def combineEvent
if (errordRecord.size()>0){
    combineEvent                        = [batchChangeSet:[batchChangeSetPart:[batchChangeSetPartStart,batchChangeSetPartError,batchChangeSetPartEnd]]]
}else{
    combineEvent                        = [batchChangeSet:[batchChangeSetPart:[batchChangeSetPartStart,batchChangeSetPartEnd]]]
}

def events                              = [batchParts:combineEvent]

def responseFinal                       = ''


/** Build response body based on emPayload flag **/
if(emPayload== 'true'){
    responseFinal        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:status,totalRecords:successRecord.size()+errordRecord.size(),invalidRecords:invalidRecords,inactiveSubsidiaryIDs:inactiveSubsidiaryIDs.toString(),processed:successRecord.size(),failed:errordRecord.size(),messageLog:response,EMEvent:events]])
}else{
    responseFinal        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:status,totalRecords:successRecord.size()+errordRecord.size(),invalidRecords:invalidRecords,inactiveSubsidiaryIDs:inactiveSubsidiaryIDs.toString(),processed:successRecord.size(),failed:errordRecord.size(),messageLog:response]])
}

println(responseFinal)


println(writter.toString())