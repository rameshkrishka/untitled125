import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import groovy.util.Node;
import groovy.util.XmlNodePrinter
import groovy.xml.XmlUtil;
import groovy.json.JsonOutput
import java.util.HashMap;

File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\response.xml')

def writter =  new StringWriter()
def builder = new MarkupBuilder(writter)
def ID    = new Date().format("yyyyMMddHHmmssS")
def date = new Date().format("yyyy-MM-dd'T'HH:mm:ss.S")
println(date)
def mandatoryFieldsFOLocation = ['externalCode','startDate','endDate','name','status','timezone']
def mandatoryFieldsFOCorporateAddress = ['city','country','address1','county','customString1','customString2','zipCode']
def mandatoryFieldsFOCompany= ['externalCode']

def uuid            = "AGDiykxNMjS9gEOWil19irJKnlNr8"
def responseBody    = new XmlSlurper().parse(sampleFile)
def successRecord     = []
def errordRecord   = []
def response        = []
def responseEM      =[]
def entitiName      = 'FOCompany'
def responseSegment = "$entitiName"+"UpsertResponse"
startDateCheckFlag = false
parentCompanyAssociationCheckFlag = false
def description = ''
def subsidiaryCode = 'TEst1'
def  emPayload = 'false'


def startEMMonitoredProcess     = [EMMonitoredProcess:["EMEventPayload":"CloudIntegration","processDefinitionName":"Replicate $entitiName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def startEMEventAttribute       = [EMEventAttribute:["name":"Details","value":"iFlow Processing Started"]]
def EMeventStart                = ["process":startEMMonitoredProcess,"eventAttributes":startEMEventAttribute,"eventDescription":"$subsidiaryCode","eventTime":date,"eventName":"iFlow Start","eventType":"START"]
def endEMMonitoredProcess       = [EMMonitoredProcess:["EMEventPayload":"CloudIntegration","processDefinitionName":"Replicate $entitiName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def endEMEventAttribute         = [EMEventAttribute:["name":"Details","value":"iFlow Processing Started"]]
def endEMEventPayload           = [EMEventPayload:["id":ID,"fileName":"response.json","fileType":"json","payload":sampleFile.bytes.encodeBase64().toString(),"mimeType":"application/json","type":"JSON"]]
def EMeventEnd                  = ["process":endEMMonitoredProcess,"eventAttributes":endEMEventAttribute,eventPayload:endEMEventPayload,"eventDescription":"iFlow Ends","eventTime":date,"eventName":"iFlow End","eventType":"END"]
def combineEvent                = [EMeventStart,EMeventEnd]
def events                      = [EMEvent:combineEvent]


if (startDateCheckFlag == false){
    description = "Please check start date"
} else if(parentCompanyAssociationCheckFlag == false){
    description = "Please check parent company association"
}

response.add([groupCode:"",subsidiaryCode:subsidiaryCode,status:'failed',description:description])

if (emPayload== 'true'){
    response        = JsonOutput.toJson(["$entitiName":[uuid:uuid,status:'failed',totalRecords:'1',processed:'0',failed:'1',messageLog:response,EMevent:events]])
} else{
    response        = JsonOutput.toJson(["$entitiName":[uuid:uuid,status:'failed',totalRecords:'1',processed:'0',failed:'1',messageLog:response]])

}

println(response)
/** EMEvent Xml for Upsert**/

def event = [EMEvent:combineEvent]
emResponse        = JsonOutput.toJson(event)

//println(emResponse)

/** EMEvent Xml for Upsert**/

builder.batchParts {
    batchChangeSet{
    EMEvent {
        responseBody."$responseSegment".each { r ->
            batchChangeSetPart{
                method("UPSERT")
            EMEvent {
                process {
                    EMMonitoredProcess {
                        processDefinitionId("CloudIntegration")
                        processDefinitionName("Replicate $entitiName Data to Group Instance")
                        processType("INTEGRATION")
                        processInstanceId(uuid)
                        processInstanceName(uuid)
                    }
                }
                eventAttributes {
                    EMEventAttribute {
                        name("Details")
                        value("iFlow Processing Started")
                    }
                }
                eventDescription("iFlow started")
                eventTime(date)
                eventName("iFlow - Start")
                eventType("START")
            }
            if (errordRecord.size() > 0) {
                EMEvent {
                    process {
                        EMMonitoredProcess {
                            processDefinitionId("CloudIntegration")
                            processDefinitionName("Replicate $entitiName Data to Group Instance")
                            processType("INTEGRATION")
                            processInstanceId(uuid)
                            processInstanceName(uuid)
                        }
                    }
                    eventAttributes {
                        EMEventAttribute {
                            name("Details")
                            value("iFlow Processing Completed")
                        }
                    }
                    eventPayload {
                        EMEventPayload {
                            id(ID)
                            fileName("report.txt")
                            fileType("txt")
                            payload(responseBody.toString().bytes.encodeBase64().toString())
                            mimeType("text/plain")
                            type("TEXT")

                        }
                    }
                    eventDescription("iFlow Ends")
                    eventTime(date)
                    eventName("iFlow - End")
                    eventType("ERROR")
                }
            }
            EMEvent {
                process {
                    EMMonitoredProcess {
                        processDefinitionId("CloudIntegration")
                        processDefinitionName("Replicate $entitiName Data to Group Instance")
                        processType("INTEGRATION")
                        processInstanceId(uuid)
                        processInstanceName(uuid)
                    }
                }
                eventAttributes {
                    EMEventAttribute {
                        name("Details")
                        value("iFlow Processing Completed")
                    }
                }
                if (errordRecord.size() > 0) {
                    eventPayload {
                        EMEventPayload {
                            id(ID)
                            fileName("response.xml")
                            fileType("xml")
                            payload(responseBody.toString().bytes.encodeBase64().toString())
                            mimeType("text/xml")
                            type("XML")
                        }
                    }
                }
                eventDescription("iFlow Ends")
                eventTime(date)
                eventName("iFlow - End")
                eventType("END")
            }
        }
    }
    }
}
}
println(writter.toString())
//
////def parseXML = new XmlSlurper().parseText(writter.toString())
////def builderJSON = new groovy.json.JsonBuilder()
////def root = builderJSON.EMEvent {
////        parseXML.EMEvent.each { r ->
////            println('ki')
////            EMEvent{
////
////            }
////        }
////
////
////    }
//
//
//
////println(builderJSON.toString())
//status = successRecord.size()==errordRecord.size()?"failed":"processed"
////validRecords    = validRecord.size()>0?JsonOutput.toJson([FOLocation:[FOLocation:validRecord]]):""
////invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson([FOLocation:[FOLocation:invalidRecord]]):""
//response        = JsonOutput.toJson(["$entitiName":[uuid:uuid,status:status,totalRecords:successRecord.size()+errordRecord.size(),processed:successRecord.size(),failed:errordRecord.size(),messageLog:response]])
//println(response)
////println(response)
//
////def checkFieldValueExist(List field, segment){
////    def missedFields = []
////    field.each {   f  ->
////        def getfieldValue = segment.get(f)
////        if(getfieldValue == '' || getfieldValue == null){
////            missedFields.add(f)
////        }
////    }
////    return  missedFields
////}
