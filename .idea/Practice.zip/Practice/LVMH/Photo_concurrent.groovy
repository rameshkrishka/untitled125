
def  response               = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/test.xml')

def upsertResponse          = new XmlSlurper().parse(response)


P_externalCode = "9000106"

def userID = ""
upsertResponse.PerPerson.employmentNav.EmpEmployment.each{ eachEmp ->
    if (eachEmp.userId.text().contains("-")){
        if (eachEmp.userId.text().split("-").getAt(1) == P_externalCode){
            userID = eachEmp.userId.text()
        }
    }
}


if (userID == ""){
    userID =  upsertResponse.PerPerson.personIdExternal.text()
}



println(userID)