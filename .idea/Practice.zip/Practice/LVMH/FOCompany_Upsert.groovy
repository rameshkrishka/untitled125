import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder

File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\company.json')
def responseBody    = new JsonSlurper().parse(sampleFile)
def writter =  new StringWriter()
def builder = new MarkupBuilder(writter)
entityName = "FOCompany"


def fieldap = ["name":"name","cust_areaGroup":"areaGroup","cust_ESSAccess":"cust_ESSAccess","cust_isCompanyInterfacedOrMaster":"cust_isCompanyInterfacedOrMaster"]
def object = "FOCompany"



    builder."$object"{
        responseBody."$entityName"."$entityName".each{ r ->
            "$object"{
                def fieldNameMap = [:]
                r.each{ key,value->
                    def getField = fieldap.get(key,'')
                    fieldap.get(key,'') != ''?fieldNameMap.put(getField,value):''
                }
                fieldNameMap.each{key,val ->
                    if(key == "cust_ESSAccess" && val == ''){
                        val = 'Yes'
                    }
                    if(key == 'cust_isCompanyInterfacedOrMaster' ){
                        val = 'Slave_Interfaced'
                    }
                    "$key"(val)
                }
            }

    }
}

println(writter.toString())

def getFieldMap(segment){

}