
def M1
def M2
def M3
def M4
def M5


if M3 validation failed {
    // reject all send EM Payload
} if (validation is OK) {
    Create batch upsert  and upsert
    upsert = success{
        send success result  with all (EM Payload)
    }else if (upsert = invalid reference) {
        send res with all failed - backup JMs  (EM Payload)
    } else if (upsert != invalid reference){
        send res with all failed (EM Payload)
    }
}


Group ---
2010
2015
2020
----
Maison "P123 /1999"
----