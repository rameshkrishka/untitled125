import groovy.json.JsonOutput
import groovy.json.JsonSlurper


File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\location3.json')

def mandatoryFieldsFOLocation = ['externalCode','startDate','endDate','name','status','timezone']
def mandatoryFieldsFOCorporateAddress = ['addressNavDEFLT/FOCorporateAddressDEFLT/city','addressNavDEFLT/FOCorporateAddressDEFLT/country','addressNavDEFLT/FOCorporateAddressDEFLT/address1','addressNavDEFLT/FOCorporateAddressDEFLT/county','addressNavDEFLT/FOCorporateAddressDEFLT/customString1','addressNavDEFLT/FOCorporateAddressDEFLT/customString2','addressNavDEFLT/FOCorporateAddressDEFLT/zipCode']
def mandatoryFieldsFOCompany= ['companyFlxNav/FOCompany/externalCode']

def uuid            = "AGDiykxNMjS9gEOWil19irJKnlNr"
def responseBody         = new JsonSlurper().parse(sampleFile)
def validRecord     = []
def invalidRecord   = []
def response        = []
def entityName      = 'FOLocation'
def totalRecords                = 0

responseBody."$entityName"."$entityName".each { def r ->
    totalRecords = totalRecords +1
    println(r.containsKey("companyFlxNav"))
    if (checkFieldValueExist(mandatoryFieldsFOLocation,r).size() == 0 && checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT != null? r.addressNavDEFLT.FOCorporateAddressDEFLT:null).size() == 0 &&  checkCompanyFieldValueExist(mandatoryFieldsFOCompany,r.companyFlxNav.isEmpty() == true?null:r.companyFlxNav.FOCompany).size() == 0) {
        validRecord.add(r)
        response.add([groupCode:"",subsidiaryCode:r.externalCode,status:"processing",description:"processing"])
    }
    else {
        invalidRecord.add(r)
        def missingFieldList= checkFieldValueExist(mandatoryFieldsFOLocation,r)+checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT != null? r.addressNavDEFLT.FOCorporateAddressDEFLT:null)+checkCompanyFieldValueExist(mandatoryFieldsFOCompany,r.companyFlxNav.isEmpty() == true?null:r.companyFlxNav.FOCompany)
        response.add([groupCode:"",subsidiaryCode:r.externalCode,status:"failed",description:"Mandatory field "+missingFieldList+" missing"])

    }
}

println "total "+totalRecords.getClass()
validRecords    = validRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":validRecord]]):""
invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":invalidRecord]]):""
response        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]])

println "nvalid"+invalidRecords.size()
def checkFieldValueExist(List field, segment){
    def missedFields = []
    field.each {   f  ->
        def getfieldValue = segment.get(f)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}
//println(checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT.FOCorporateAddressDEFLT))

def checkAddressFieldValueExist(List field, segment){
    def missedFields = []
    if (segment != null){
        field.each {   f  ->
//            println(f)
            def fieldName = f.toString().split('[/]').getAt(2).toString()
//            println(fieldName)
            def getfieldValue = segment.get(fieldName)
//            println(getfieldValue)
            if(getfieldValue == '' || getfieldValue == null){
                missedFields.add(f)
            }
        }
    }else{
        missedFields.add(field)
    }
    return  missedFields
}
def checkCompanyFieldValueExist(List field, segment){
    def missedFields = []
    println(segment)
    if(segment !=null){
        field.each {   f  ->
            def fieldName = f.toString().split('[/]').getAt(2).toString()
            println(fieldName)
            def getfieldValue = segment.get("externalCode")
            println(getfieldValue)
            if(getfieldValue == '' || getfieldValue == null){
                missedFields.add(f)
            }
        }
    }else{
        missedFields.add(field)
    }

    return  missedFields
}

println("response\n"+response)
println("validRecords\n"+validRecords)
println("invalidRecords\n"+invalidRecords)


