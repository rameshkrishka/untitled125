import java.text.DateFormat
import java.text.SimpleDateFormat
def  response               = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/company.xml')
def  lookup               = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/Company_lookup')
import groovy.xml.XmlUtil;

def p_externalCode = '123'
println(lookup)

def lookupParse         =  new XmlSlurper().parse(lookup) // parse upsert XML
def responseParse       =  new XmlSlurper().parse(response) // parse get response
def bufferDays          =  365
def errorMessage = []

startDateMap                                = [:]
parentCompanyAssociationMap                 = [:]

lookupParse.FOCompany.each{ r ->
        def externalCode                        = r.externalCode.text()
        def startDate                           = r.startDate.text()
        def cust_ParentCompanyAssociationProp   = r.cust_ParentCompanyAssociationProp.text()
        startDateMap.put(externalCode,startDate)
        parentCompanyAssociationMap.put(externalCode,cust_ParentCompanyAssociationProp)
   }

println(parentCompanyAssociationMap)


def firstTimeInsertFlag                 = ''
def startDateCheckFlag                  = ''
def parentCompanyAssociationCheckFlag   = ''
def durationDays                        = ''

responseParse.FOCompany.each { r ->
    def externalCode = r.externalCode.text()
    def startDateStr = r.startDate.text()
    def lookUpdateSrt = startDateMap.get(externalCode)
    def duration = ''
    def parentCompanyAssociation = r.cust_ParentCompanyAssociationProp.text()
    if (p_externalCode == '' || p_externalCode == null) {
        r.startDate = "1900-01-01T00:00:00.000"
        firstTimeInsertFlag = true
    } else if (r.status == 'A') {
        r.startDate = startDateStr
    } else if (r.status == 'I') {
        if (p_externalCode != '' || p_externalCode != null) {
            use(groovy.time.TimeCategory) {
                if (p_externalCode != '') {
                    DateFormat startDate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
                    Date dateStart = startDate.parse(startDateStr)
                    DateFormat lookUpdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
                    Date dateLookup = lookUpdate.parse(lookUpdateSrt)
                    duration = dateStart - dateLookup
                    durationDays = duration.toString().replaceAll(" days", '')
                }
            }
            if (durationDays.toInteger() >= bufferDays) {
                startDateCheckFlag = true
            } else {
                startDateCheckFlag = false
                errorMessage.add("Failed: Trying to inactivate the record with start date > 1 year")
            }
        }
    }
}
println(durationDays)




    def parentCompanyAssociation        = responseParse.FOCompany.cust_ParentCompanyAssociationProp.text().toString()
    if (parentCompanyAssociation.toString() == parentCompanyAssociationMap.get(p_externalCode).toString() ){
        parentCompanyAssociationCheckFlag = true
    }else{
        parentCompanyAssociationCheckFlag = false
    }
    if(parentCompanyAssociationCheckFlag   == false){
        errorMessage.add("Parent company control validation failed")
    }



println("firstTimeInsertFlag" + firstTimeInsertFlag)
println("startDateCheckFlag" + startDateCheckFlag)
println("parentCompanyAssociationCheckFlag" + parentCompanyAssociationCheckFlag)
//
