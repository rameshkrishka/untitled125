
def a = new Date().format("yyyyMMdd'T'SS")