/*
Use: check mandatory parameters
 */

import groovy.json.JsonOutput


    def uuid                        = '123'                                                                                          /** Get uuid property**/
    def entityName                  = "Position"                                                                                                  /** parameter for response header name**/
    def response                    = []                                                                                                            /** parameter to store response body**/
    def body                        = "exception message";                                                                              /** get incoming body message**/
    def emPayload                   = "true"
exception                    = "hiiii"
def positionEntityMap = ["Position":"POSITION"]
println(positionEntityMap.get(entityName) == null?entityName:positionEntityMap.get(entityName))
    /** loop through mandatoryParameters and check where paramter value is empty **/

    /** create propperty to check where missing parameter exist or not**/

    /** create repsponse body **/
//    if (missingParameter.size()>0){
//        responseBody."$entityName"."$entityName".each {  r ->
//            response.add([groupCode:"",subsidiaryCode:r.externalCode,status:"failed",description:"Mandatory parameter "+missingParameter+" missing"])
//        }
//    }
//    mandatoryParametersResponse        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"Error",totalRecords:responseBody."$entityName"."$entityName".size(),processed:'0',failed:responseBody."$entityName"."$entityName".size(),messageLog:response]])


    def date                                = new Date().format("yyyy-MM-dd'T'HH:mm:ss.S")      /** Parameter for EMEvent DateTime**/
    def ID                                  = new Date().format("yyyyMMddHHmmssS")              /** Parameter for payload ID**/
    def fileName_EM                         = uuid+".txt"                                              /** File name **/

    /** EM Event start Payload **/
    def startEMMonitoredProcess             = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance ","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
    def startEMEventAttribute               = [EMEventAttribute:["name":"Details","value":"Parameter validation started"]]
    def EMeventStart                        = ["process":startEMMonitoredProcess,"eventAttributes":startEMEventAttribute,"eventDescription":"$uuid  - Initial acknowledgement from group","eventTime":date,"eventName":"Parameter validation started","eventType":"START"]
    /** EM Event error Payload **/
    def errorEMMonitoredProcess             = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid,"hasErrors":"true"]]
    def errorEMEventAttribute               = [EMEventAttribute:["name":"Details","value":"Error while execution at group end,  for more details or conatct technical team for more details with uuid - $uuid"]]
    def errorEMEventPayload                 = [EMEventPayload:["id":ID,"fileName":fileName_EM,"fileType":"txt","payload":exception.bytes.encodeBase64().toString(),"mimeType":"text/plain","type":"TEXT"]]
    def EMeventError                        = ["process":errorEMMonitoredProcess,"eventAttributes":errorEMEventAttribute,eventPayload:errorEMEventPayload,"eventDescription":"$uuid - Initial acknowledgement from group","eventTime":date,"eventName":"Parameter validation failed","eventType":"ERROR"]
    /** EM Event end Payload **/

    def endEMMonitoredProcess               = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
    def endEMEventAttribute                 = [EMEventAttribute:["name":"Details","value":"Error"]]
    def EMeventEnd                          = ["process":endEMMonitoredProcess,"eventAttributes":endEMEventAttribute,"eventDescription":"$uuid - Initial acknowledgement from group","eventTime":date,"eventName":"Error","eventType":"END"]

    def batchChangeSetPartStart             = [method:"UPSERT",EMEvent:[EMEvent:EMeventStart]]
    def batchChangeSetPartError             = [method:"UPSERT",EMEvent:[EMEvent:EMeventError]]
    def batchChangeSetPartEnd               = [method:"UPSERT",EMEvent:[EMEvent:EMeventEnd]]


        combineEvent                        = [batchChangeSet:[batchChangeSetPart:[batchChangeSetPartStart,batchChangeSetPartError,batchChangeSetPartEnd]]]


    def events                              = [batchParts:combineEvent]

responseSegment = [groupCode:"",uuid:uuid,status:"Error",description:"Error"]


    /** Reposne body**/
    def response_EM
    if (emPayload.toUpperCase() == 'TRUE'){
        response_EM            = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"Error",messageLog:responseSegment,EMEvent:events]])
    }else{
        response_EM            = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"Error",messageLog:responseSegment]])
    }

println(response_EM)
    /** create property fo response body **/
