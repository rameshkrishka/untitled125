import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil;

def response                = new File('C:/Users/i524259/OneDrive - SAP SE/Practice/LVMH/locationSampleFile/education.xml')


def allUserList = "'MH0001490','MH_IT11500233','MH0001494'"

def parsePayload            =  new XmlSlurper().parse(response)
def writter                 = new StringWriter()                                /** String writter for XML build **/
def builder                 = new MarkupBuilder(writter)                        /** XML markup builder declaration **/
//def builder = new groovy.xml.StreamingMarkupBuilder()
def inactiveSubsidiaryIDs   = []
def userMap     = [:]

StringBuilder filterQuery = new StringBuilder()
StringBuilder missingMaisonEmployeeAtGroup = new StringBuilder()
allUserList.replaceAll("'",'').toString().split(',').each { r ->
    def userExist      = false
    parsePayload.PerPerson.each{ eachEducation ->
        userMap.put(r,eachEducation.personIdExternal)
        if (r.toString() == eachEducation.customString1.text().toString()){
            filterQuery.append("'").append(eachEducation.personIdExternal).append("'").append(",")
            userExist = true
        }
    }
    missingMaisonEmployeeAtGroup.append(r).append(",")
}
println(userMap)
println(filterQuery)
println(missingMaisonEmployeeAtGroup)
println(userMap.get("MH_IT115002332"))
//parsePayload.Background_Education.each{ r ->
//    if(r.userIdNav == ''){
//        inactiveSubsidiaryIDs.add(r.userId.text())
//
//    }else{
//        builder.batchChangeSetPart{
//            // batchChangeSetPart{
//            method("DELETE")
//            def backgroundElementID = r.backgroundElementId
//            def userID              = r.userId
//            user(userID)
//            uri("Background_Education(backgroundElementId=${backgroundElementID},userId='${userID}')")
//            // Background_Education{
//            //     Background_Education{
//            //         backgroundElementId(backgroundElementID)
//            //         userId(userID)
//            //     }
//            // }
//            // }
//        }
//    }
//}
//println(inactiveSubsidiaryIDs)
println(writter.toString())
