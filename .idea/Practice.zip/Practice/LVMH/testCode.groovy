import groovy.json.JsonOutput
import groovy.json.JsonSlurper


def d = "1235_P_Ju"
def s = d.toString().contains("_T_")
println(s)

def a = "'1024137','1024137'"
def f=  [123,123]
//def filterQuery              = a.toString().replaceAll("'","")	    /** Get Maison Name **/
def userID                   =[123,123,245]
//def UserIDs                 = filterQuery.split(',').toUnique().toString().replaceAll("\\[","").replaceAll("]","")//[filterQuery]
def uniqueUserID = userID.unique()
def filterQuery         = new StringBuilder()

uniqueUserID.each{ eachUser ->

    filterQuery.append("'").append(eachUser).append("'").append(",")
}



println(userID.unique())
println(filterQuery.toString().reverse().drop(1).reverse())
//def uniqueUserIDs           = UserIDs.unique()
//def g = a.unique()
//println(uniqueUserIDs)
//def b= a.replaceAll("<come>","")


//println "A "+b
lastModifiedDateTime = "2021-08-19T09:55:06.000"
println lastModifiedDateTime.toString().substring(0,10)
File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\location.json')

def mandatoryFieldsFOLocation = ['externalCode','startDate','endDate','name','status','timezone']
def mandatoryFieldsFOCorporateAddress = ['addressNavDEFLT/FOCorporateAddressDEFLT/city','addressNavDEFLT/FOCorporateAddressDEFLT/country','addressNavDEFLT/FOCorporateAddressDEFLT/address1','addressNavDEFLT/FOCorporateAddressDEFLT/county','addressNavDEFLT/FOCorporateAddressDEFLT/customString1','addressNavDEFLT/FOCorporateAddressDEFLT/customString2','addressNavDEFLT/FOCorporateAddressDEFLT/zipCode']
def mandatoryFieldsFOCompany= ['companyFlxNav/FOCompany/externalcode']

def uuid            = "AGDiykxNMjS9gEOWil19irJKnlNr"
def responseBody    = new JsonSlurper().parse(sampleFile)
def validRecord     = []
def invalidRecord   = []
def response        = []
def entityName      = 'FOLocation'


responseBody."$entityName"."$entityName".each { def r ->
    println(r.companyFlxNav)
    if (checkFieldValueExist(mandatoryFieldsFOLocation,r).size() == 0 && checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT.FOCorporateAddressDEFLT).size() == 0 &&  checkCompanyFieldValueExist(mandatoryFieldsFOCompany,r.companyFlxNav.FOCompany).size() == 0) {
        validRecord.add(r)
        response.add([groupCode:"",subsidiaryCode:r.externalCode,status:"processing",description:"processing"])
    }
    else {
        invalidRecord.add(r)
//        println(invalidRecord)


        def missingFieldList=  checkFieldValueExist(mandatoryFieldsFOLocation,r)+checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT.FOCorporateAddressDEFLT)+checkCompanyFieldValueExist(mandatoryFieldsFOCompany,r.companyFlxNav != null?r.companyFlxNav.FOCompany:null)


        response.add([groupCode:"",subsidiaryCode:r.externalCode,status:"failed",description:"Mandatory field "+missingFieldList+" missing"])

    }
}
println(response.getClass())

validRecords    = validRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":validRecord]]):""
invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":invalidRecord]]):""
response        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]])


def checkFieldValueExist(List field, segment){
    def missedFields = []
    field.each {   f  ->
        def getfieldValue = segment.get(f)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}
//println(checkAddressFieldValueExist(mandatoryFieldsFOCorporateAddress,r.addressNavDEFLT.FOCorporateAddressDEFLT))

def checkAddressFieldValueExist(List field, segment){
    def missedFields = []
    field.each {   f  ->
        def fieldName = f.toString().split('[/]').getAt(2).toString()
        def getfieldValue = segment.get(fieldName)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}
def checkCompanyFieldValueExist(List field, segment){
    def missedFields = []
    println(segment)
    field.each {   f  ->
        def fieldName = f.toString().split('[/]').getAt(2).toString()
        def getfieldValue = segment.get(fieldName)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}

println("response\n"+response)
println("validRecords\n"+validRecords)
println("invalidRecords\n"+invalidRecords)


