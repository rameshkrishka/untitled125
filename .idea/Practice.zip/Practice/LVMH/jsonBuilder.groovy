import groovy.json.JsonSlurper


File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\test.json')


def company = new JsonSlurper().parse(sampleFile)
println(company)
validFOCompanySegments = []
invalidFOCompanySegments = []

//def ValidRecordBuilder = new groovy.json.JsonBuilder(company)
//def inValidRecordBuilder = new groovy.json.JsonBuilder()

//println(ValidRecordBuilder)

company.FOCompany.FOCompany.each { r ->
    if (r.name_ru_RU != '') {
        validFOCompanySegments.add(r)
    }
    else {
        invalidFOCompanySegments.add(r)
    }
}


validRecords = new groovy.json.JsonBuilder([FOLocation:[FOLocation:validFOCompanySegments]])
println(validRecords)

invalidRecords = new groovy.json.JsonBuilder([FOLocation:[FOLocation:invalidFOCompanySegments]])
println(invalidRecords)


println("valid"+validFOCompanySegments)
println("invlaid"+invalidFOCompanySegments)

