import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.groovy.json.internal.LazyMap
import groovy.json.JsonOutput
File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\minicv.xml')

def requestUserIds = 	"'1031875','1031879','99999','88888','1031882'"
def requestUserIdList = requestUserIds.replaceAll("'","")

def responseBody            = new XmlSlurper().parse(sampleFile)
def entityName              = "Background_Education"
def result                  = []

requestUserIdList.split(",").each { eachUser ->
    def userExistflag = false
    def data =[]
    responseBody."$entityName".each{ eachLine->
        if (eachUser == eachLine.userId.text()){
            userExistflag = true
            reult = data.add(["country":eachLine.country.toString(),"partnership":eachLine.partnership.toString(),"major":eachLine.major.toString(),"school":eachLine.school.toString(),"degree":eachLine.degree.toString(),"bgOrderPos":eachLine.bgOrderPos.toString(),"backgroundElementId":eachLine.backgroundElementId.toString(),"educationYear":eachLine.educationYear.toString(),"userId":eachLine.userId.toString()])
        }
    }
    if (userExistflag == false){
        reult = data
    }
    result.add(["groupEmployeeID":eachUser,"data":data])
}

response        = JsonOutput.toJson(["$entityName":["$entityName":result]])


println(response)