import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import groovy.xml.MarkupBuilder
import groovy.xml.XmlUtil;

def  sampleEmployee               = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\Employee.xml')
def parsePayload             =  new XmlSlurper().parse(sampleEmployee) // parse upsert XML


def mandatoryFieldsPerson           = ['custom_string1','logon_user_name','person_id_external','custom_stringR']
def mandatoryFieldsPersonal         = ['personal_information/custom_date1','personal_information/custom_string1','personal_information/custom_string2','personal_information/custom_string2','personal_information/first_name','personal_information/gender','personal_information/last_name','personal_information/nationality','personal_information/start_date']
def mandatoryFieldsEmail            = ['email_information/isPrimary','email_information/email_type','email_information/email_address']
def mandatoryFieldsPhone            = ['phone_information/isPrimary','phone_information/phone_type','phone_information/phone_number']
def mandatoryFieldsemployment       = ['employment_information/start_date','employment_information/originalStartDate','employment_information/user_id','employment_information/custom_date1']
def mandatoryFieldsEmpJob           = ['employment_information/job_information/company','employment_information/job_information/position','employment_information/job_information/custom_string18','employment_information/job_information/employee_class', 'employment_information/job_information/end_date','employment_information/job_information/event_reason','employment_information/job_information/fte', 'employment_information/job_information/custom_string1','employment_information/job_information/regular_temp','employment_information/job_information/start_date']

def uuid            = "AGDiykxNMjS9gEOWil19irJKnlNr"
//def responseBody    = new JsonSlurper().parse(sampleFile)
def validRecordCount     = 0
def invalidRecordCount   = 0
def totalRecordCount     = 0
def response                =[]
def entityName      = 'Employee'
StringBuilder validRecords = new StringBuilder()
StringBuilder invalidRecords = new StringBuilder()

def writter =  new StringWriter()
def builder = new MarkupBuilder(writter)
builder."$entityName"{
    parsePayload."$entityName".each {  r ->

        totalRecordCount = totalRecordCount+1
        if(r.person.personal_information == ''){
            println("null personal")
            response.add([groupCode:"",subsidiaryCode:r.person.person_id_external.text().toString(),status:"failed",description:"personal_information segment is missing"])
        }
        else if (    checkFieldValueExist(mandatoryFieldsPerson,r.person).size()                                                 == 0 &&
                checkPersonalFieldValueExist(mandatoryFieldsPersonal, r.person.personal_information).size()                 == 0 &&
                checkEmailFieldValueExist(mandatoryFieldsEmail,r.person.email_information).size()                           == 0 &&
                checkPhoneFieldValueExist(mandatoryFieldsPhone,r.person.phone_information).size()                           == 0 &&
                checkEmploymentFieldValueExist(mandatoryFieldsemployment,r.person.employment_information).size()            == 0 &&
                checkEmpJobFieldValueExist(mandatoryFieldsEmpJob,r.person.employment_information).size()    == 0) {
            def employeeSegmant= XmlUtil.serialize(r).toString().replaceAll("<\\?xml.*\\?>", "")
            validRecords.append(employeeSegmant)
            validRecordCount = validRecordCount+1
            response.add([groupCode:"",subsidiaryCode:r.person.person_id_external.text().toString(),status:"processing",description:"processing"])
        }
        else {
            def employeeSegmant= XmlUtil.serialize(r).toString().replaceAll("<\\?xml.*\\?>", "")
            invalidRecords.append(employeeSegmant)
            invalidRecordCount = invalidRecordCount+1
            def missingFieldList = checkFieldValueExist(mandatoryFieldsPerson,r.person)+
                    checkPersonalFieldValueExist(mandatoryFieldsPersonal, r.person.personal_information)+
                    checkEmailFieldValueExist(mandatoryFieldsEmail,r.person.email_information)+
                    checkPhoneFieldValueExist(mandatoryFieldsPhone,r.person.phone_information)+
                    checkEmploymentFieldValueExist(mandatoryFieldsemployment,r.person.employment_information)+
                    checkEmpJobFieldValueExist(mandatoryFieldsEmpJob,r.person.employment_information)
            println(missingFieldList)
            response.add([groupCode:"",subsidiaryCode:r.person.person_id_external.text().toString(),status:"failed",description:"Mandatory field "+missingFieldList.toString()+" missing"])
            println(response)

        }
    }
}
//println("response"+response)
//println(totalRecordCount +'totalRecordCount')
//println('countre'+invalidRecordCount)
//println('<Employee>'+invalidRecords+'</Employee>')
//
//println(validRecord)
//println(XmlUtil.serialize(validRecords))
//validRecords    = validRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":validRecord]]):""
//invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":invalidRecord]]):""
def responseJSON        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:totalRecordCount,processed:validRecordCount,failed:invalidRecordCount,messageLog:response]])


def checkFieldValueExist(List field, segment) {
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment.action != 'NO CHANGE' && segment.action != '') {
        field.each { eachField ->
            println(eachField)
            def getfieldValue = segment."$eachField"
            println(getfieldValue)
            if (getfieldValue == '' || getfieldValue == null) {
                missedFields.add(eachField.toString())
            }
        }
    }
    return missedFields
}
def checkPersonalFieldValueExist(List field,  segment){
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment != null) {
        segment.any { personal ->
            if (personal.action != 'NO CHANGE' && personal.action != '') {
                field.each { eachField ->
                    def fieldName = eachField.toString().split('[/]').getAt(1).toString()
                    def getfieldValue = personal."$fieldName"//.text().toString()//get(fieldName)
                    if (getfieldValue == '' || getfieldValue == null) {
                        missedFields.add(eachField.toString())
                    }
                }
            }
        }
    }
    return  missedFields
}
def checkEmailFieldValueExist(List field,  segment){
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment != null) {
        segment.any { email ->
            if (email.action != 'NO CHANGE' && email.action != '') {
                field.each { eachField ->
                    def fieldName = eachField.toString().split('[/]').getAt(1).toString()
                    def getfieldValue = email."$fieldName"//get(fieldName)
                    if (getfieldValue == '' || getfieldValue == null) {
                        missedFields.add(eachField.toString())
                    }
                }
            }
        }
    }
    return  missedFields
}

def checkPhoneFieldValueExist(List field, segment){
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment != null) {
        segment.any { phone ->
            if (phone.action != 'NO CHANGE' && phone.action != '') {
                field.each { eachField ->
                    def fieldName = eachField.toString().split('[/]').getAt(1).toString()
                    def getfieldValue = phone."$fieldName"//get(fieldName)
                    if (getfieldValue == '' || getfieldValue == null) {
                        missedFields.add(eachField.toString())
                    }
                }
            }
        }
    }
    return  missedFields
}
def checkEmploymentFieldValueExist(List field, segment){
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment != null) {
        segment.any { employment ->
            if (employment.action != 'NO CHANGE' && employment.action != '') {
                field.each { eachField ->
                    def fieldName = eachField.toString().split('[/]').getAt(1).toString()
                    def getfieldValue = employment."$fieldName"//get(fieldName)
                    if (getfieldValue == '' || getfieldValue == null) {
                        missedFields.add(eachField.toString())
                    }
                }
            }
        }
    }
    return  missedFields
}

def checkEmpJobFieldValueExist(List field, segment){
    def missedFields = []
//    StringBuilder missedFields = new StringBuilder()
    if (segment != null) {
        segment.each{ eachSegment ->
            eachSegment.job_information.any { job ->
                if (job.action != 'NO CHANGE' && job.action != '') {
                    field.each { eachField ->
                        def fieldName = eachField.toString().split('[/]').getAt(2).toString()
//                        println(fieldName)
                        def getfieldValue = job."$fieldName"//get(fieldName)
                        if (getfieldValue == '' || getfieldValue == null) {
                            missedFields.add(eachField.toString())
                        }
                    }
                }
            }
        }
    }
    return  missedFields
}


//
println("response\n"+responseJSON)
//println("validRecords\n"+validRecords)
//println("invalidRecords\n"+invalidRecords)
//
//

