import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.apache.groovy.json.internal.LazyMap

File sampleFile = new File('C:\\Users\\i524259\\OneDrive - SAP SE\\Practice\\LVMH\\locationSampleFile\\minicv.json')

//def mandatoryFieldsFOCompany = ['startDate','endDate','name','status','currency','country','cust_ESSAccess']
def mandatoryFieldsFOCompany             = ['externalCode','startDate','endDate','name','status','cust_DepartmentAssociationProp']
def uuid                    = "AGDiykxNMjS9gEOWil19irJKnlNr"
def responseBody            = new JsonSlurper().parse(sampleFile)
def validRecord             = []
def invalidRecord           = []
def response                = []
def maisonName
def callbackEndpoint
def callbackType
def callbackAuthType
def sfProxyEndpoint
def sfProxyAuthType
def emPayload
def entityName = "Background_Education"

def validUsers                  = []
def inValidUsers                = []
def allUsers                    = []


responseBody."$entityName".each {  r ->
println("res "+r.get("groupEmployeeID"))
    if(r.get("groupEmployeeID") == ''){
        invalidRecord.add(r)
        inValidUsers.add(r.subsidiaryEmployeeID)
        response.add([groupCode:"",subsidiaryCode:r.subsidiaryEmployeeID,status:"failed",description:"Mandatory field groupEmployeeID missing"])

    }else if (r.get("subsidiaryEmployeeID") == ''){
        invalidRecord.add(r)
        inValidUsers.add(r.subsidiaryEmployeeID)
        response.add([groupCode:"",subsidiaryCode:r.subsidiaryEmployeeID,status:"failed",description:"Mandatory field subsidiaryEmployeeID missing"])

    }else{
        validRecord.add(r)
        validUsers.add(r.subsidiaryEmployeeID)
        response.add([groupCode:"",subsidiaryCode:r.subsidiaryEmployeeID,status:"processing",description:"processing"])
    }
}

validRecords    = validRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":validRecord]]):""
invalidRecords  = invalidRecord.size()>0?JsonOutput.toJson(["$entityName":["$entityName":invalidRecord]]):""
responseMessage        = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]])
//response_EM     = [FOCompany:[uuid:uuid,status:"processing",totalRecords:responseBody.FOCompany.FOCompany.size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response]]

def date                                = new Date().format("yyyy-MM-dd'T'HH:mm:ss.S")      /** Parameter for EMEvent DateTime**/
def ID                                  = new Date().format("yyyyMMddHHmmssS")              /** Parameter for payload ID**/
def fileName_EM                         = uuid+".xml"                    /** File name **/

def startEMMonitoredProcess             = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def startEMEventAttribute               = [EMEventAttribute:["name":"Details","value":"iFlow Processing Started"]]
def EMeventStart                        = ["process":startEMMonitoredProcess,"eventAttributes":startEMEventAttribute,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow Start","eventType":"START"]

def errorEMMonitoredProcess               = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def errorEMEventAttribute                 = [EMEventAttribute:["name":"Details","value":"iFlow Processing Ends"]]
def errorEMEventPayload                   = [EMEventPayload:["id":ID,"fileName":fileName_EM,"fileType":"xml","payload":responseMessage.bytes.encodeBase64().toString(),"mimeType":"text/xml","type":"XML"]]
def EMeventError                          = ["process":errorEMMonitoredProcess,"eventAttributes":errorEMEventAttribute,eventPayload:errorEMEventPayload,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow End","eventType":"ERROR"]

def endEMMonitoredProcess               = [EMMonitoredProcess:["processDefinitionId":"CloudIntegration","processDefinitionName":"Replicate $entityName Data to Group Instance","processType":"INTEGRATION","processInstanceId":uuid,"processInstanceName":uuid]]
def endEMEventAttribute                 = [EMEventAttribute:["name":"Details","value":"iFlow Processing Ends"]]
def endEMEventPayload                   = [EMEventPayload:["id":ID,"fileName":"$fileName_EM","fileType":"xml","payload":responseMessage.bytes.encodeBase64().toString(),"mimeType":"text/xml","type":"XML"]]
def EMeventEnd                          = ["process":endEMMonitoredProcess,"eventAttributes":endEMEventAttribute,"eventPayload":endEMEventPayload,"eventDescription":"$uuid","eventTime":date,"eventName":"iFlow End","eventType":"END"]

def combineEvent
if (invalidRecord.size()>0){
    combineEvent                        = [EMeventStart,EMeventError,EMeventEnd]
}else{
    combineEvent                        = [EMeventStart,EMeventEnd]
}

def events                              = [EMEvent:combineEvent]

response_EM            = JsonOutput.toJson(["$entityName":[uuid:uuid,status:"processing",totalRecords:responseBody."$entityName"."$entityName".size(),processed:validRecord.size(),failed:invalidRecord.size(),messageLog:response,EMEvent:events]])

println(response_EM)


def checkFieldValueExist(List field, segment){
    def missedFields = []
    field.each { f  ->
        def getfieldValue = segment.get(f)
        if(getfieldValue == '' || getfieldValue == null){
            missedFields.add(f)
        }
    }
    return  missedFields
}


//
//println("response\n"+response)
//println("validRecords\n"+validRecords)
//println("invalidRecords\n"+invalidRecords)


//println("valid"+validRecord)
//println("invlaid"+invalidRecord)

//org.apache.groovy.json.internal.LazyMap
//def checkFieldExist(List field, segment){
//    def fieldNotExistFlag = ''
//    field.each {   f  ->
//        def exist = segment.containsKey(f)
//        if(exist == false){
//            fieldNotExistFlag = 'Y'
//        }
//    }
//    return  fieldNotExistFlag
//}