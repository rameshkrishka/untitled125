

if (punchOutTime > scheduledEndTime) {
    /*split the time for OT (over time) and regular
    Example1:
    Work Schedule: 9:00 PM to 5:00 AM  no break
    01 Jan   Day1 Shift Code: REG_NIGHT Working Hours: 9 PM to 11:59 PM
    02 Jan   Day2 Shift code: NIGHT Working Hours: 12:00 AM to 11:59 PM  Break: 5:00 AM (End Time) to 9 PM (Start Time) ShiftBreak: Yes
    Note: always read +1 day workschedule to get the end time. Any Punch In time which is after Work Schedule  End Time we should consider after_OT

    Time Machine punches:
            01 Jan Punch In 8 PM
            02 Jan Punch Out 4.30 AM

    Expected output
                Expected CPI:        01 Jan                 WORK               9:00 PM to 11:59 PM
                                                            WORK                12:00 AM to 5:00 AM


    Example2:
    Work Schedule: 9:00 PM to 5:00 AM  no break
    02 Jan Day5 Shift code: NIGHT Working Hours: 12:00 AM to 11:59 PM  Break: 5:00 AM (End Time) to 9 PM (Start Time) ShiftBreak: Yes
    03 Jan Day6 Shift code: REG_NIGHT Working Hours: 12:00 AM to 5:00 AM
    Note: always read +1 day workschedule to get the end time. Any Punch In time which is after Work Schedule  End Time we should consider after_OT

    Time Machine punch:
        02 Jan Punch In 8 PM
        03 Jan Punch Out 5:09 AM
        03 Jan Punch In 5:10 AM
        03 Jan Punch Out 5:20 AM
        03 Jan Punch In 5:30 AM
        03 Jan Punch Out 5:40 AM
        03 Jan Punch In 6:0 AM
        03 Jan Punch Out 6:30 AM

Expected CPI:                   01 Jan                    WORK                 9: PM to 11:59 PM
                                02 JAN                    WORK                 12:00 AM to 5:00 AM
                                                          NIGHT_OT          05:01 AM to 5:09 AM
                                                          After_OT            5:10 AM to 5:20 AM
                                                          After_OT            5:30 AM to 5:40 AM
                                                          After_OT            6:00 AM to 6:30 AM

    */
}
else{
    // add only regular time
}