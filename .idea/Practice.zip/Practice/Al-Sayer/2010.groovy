import groovy.xml.MarkupBuilder

import java.text.DateFormat
import java.text.SimpleDateFormat


def records = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/2010/new 327.xml')

def value = ""
//   def timeType = ['3000','3010','3015','3001','3015_BS','3015_AS']
StringBuilder output = new StringBuilder()
records.EmployeeTimeSheet.each{ et ->
//    println('hi')
    def userId = et.userId.text()
    def approvalStatus = et.approvalStatus
    et.employeeTimeValuationResult.EmployeeTimeValuationResult.each { ete ->
        // if ( timeType.contains(ete.employeeTimeNav.EmployeeTime[0].timeType.text()) == true){
        def timeTypeCode = ete.payTypeName.text()
        def startDate = dateTrans(ete.bookingDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
        def hoursAndMinutes = ete.hoursAndMinutes.text()
        def hours = hoursAndMinutes.tokenize(':')[0].toString()
        def min = hoursAndMinutes.tokenize(':')[1].toInteger() / 60
        min = min.toString().tokenize('.')[1]
        if (min == null) {
            min ='00'
        } else {
            min = min.toString().length() > 1 ? min.toString().substring(0, 2) : min
        }
        hoursAndMinutes =  hours+':'+min
//        hoursAndMinutes = format('%,.2f', hoursAndMinutes)
        // def startTime = dateTrans(ete.employeeTimeNav.EmployeeTime[0].startTime.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'HH:mm:ss')
        // def endTime = ete.employeeTimeNav.EmployeeTime[0].endTime.text()
        //  endTime = dateTrans(ete.employeeTimeNav.EmployeeTime[0].endTime.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'HH:mm:ss')
        // def externalCode = ete.employeeTime
        output.append(userId).append(',').append(timeTypeCode).append(',').append(startDate).append(',').append(hoursAndMinutes).append(',').append(',').append(approvalStatus).append('\n')
        // }
    }
}
println(output)




def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}
