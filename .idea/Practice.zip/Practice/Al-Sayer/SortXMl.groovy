


import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;
import groovy.xml.XmlUtil
def xml             = new XmlSlurper().parse('C:/Users/i524259/Downloads/4000002054.xml')
def upc_map = [:]
xml.TransportationDocument.Item.each{ prd ->
if (prd.CategoryCode.text() == 'PRD'){
    def ParentItemID = prd.HierarchyRelationship.ParentItemID.text()
    def upc_code         = prd.AddlData.Upc.text()
    upc_map.put(ParentItemID,groovy.xml.XmlUtil.serialize(prd))

}
}

println(upc_map)
xml.TransportationDocument.Item.each{ r ->
    println('hi')

}

//def nodes           = xml.'**'.findAll{it.name() && !it.text()}
//def removeNode      = { node ->
//    def parent      = node.parent()
//    parent.remove(node)
//}
//
//nodes.each{removeNode(it)}
//println groovy.xml.XmlUtil.serialize(xml)
