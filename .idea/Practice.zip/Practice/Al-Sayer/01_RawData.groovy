import groovy.xml.MarkupBuilder
import java.text.SimpleDateFormat;
import java.text.DateFormat;
def rawRecords = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/01 Raw Data Update/XML/t1.xml')
def person = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/01 Raw Data Update/XML/fullLoadPINNumber.txt')

def pinNumerMap =[:]
person.PerPerson.each{ p ->
    def userID = p.personIdExternal.text()
    def pinNumber = p.customString2.text()
    pinNumerMap.put(pinNumber,userID )
}
println(pinNumerMap)

StringBuilder rawRecordItems = new StringBuilder()
StringBuilder rawRecordMissedPIN = new StringBuilder()
rawRecords.row.each{ r ->
        def userID = pinNumerMap.get(r.PIN.text(), '')
    def punchDateForExternalCode = dateTrans(r.Date.text(),'yyyy-MM-dd HH:mm:ss.S','yyyyMMdd')
    def punchTimeForExternalCode = dateTrans(r.Time.text(),'yyyy-MM-dd HH:mm:ss.S','HHmmssS')
    def id_Value = r.ID.text()
    def ID = r.ID.text()+'_'+punchDateForExternalCode+punchTimeForExternalCode
    def Date = dateTrans(r.Date.text(),'yyyy-MM-dd HH:mm:ss.S','yyyy-MM-dd')
    def Time = dateTrans(r.Time.text(),'yyyy-MM-dd HH:mm:ss.S','HH:mm:ss')
        def TransType = r.TransType
        def PIN  = r.PIN
        def Address = r.Address
        def InsertionDateTime = dateTrans(r.InsertionDateTime.text(),'yyyy-MM-dd HH:mm:ss.S','yyyy-MM-dd HH:mm')
    if (userID != ''){
        println('hi')
        rawRecordItems.append(userID).append(',').
                        append(ID).append(',').
                        append(Date).append(',').
                        append(Time).append(',').
                        append(TransType).append(',').
                        append(PIN).append(',').
                        append(Address).append(',').
                        append(InsertionDateTime).append('\n')
    }
    else{
        rawRecordMissedPIN.append(id_Value).append(',').
                        append(Date).append(',').
                        append(Time).append(',').
                        append(TransType).append(',').
                        append(PIN).append(',').
                        append(Address).append(',').
                        append(InsertionDateTime).append('\n')
        //ID,Date,Time,TransType,PIN,Address,InsertionDateTime
    }
}


def writer = new StringWriter();
def builder = new MarkupBuilder(writer);
builder.cust_Missed_PIN_Raw_Punches{
    rawRecordMissedPIN.eachLine { LineT ->
        cust_Missed_PIN_Raw_Punches {
            externalCode LineT.tokenize(',')[0]
            cust_Address LineT.tokenize(',')[5]
            cust_Date LineT.tokenize(',')[1]
            cust_InsertionDateTime LineT.tokenize(',')[6]
            cust_PIN LineT.tokenize(',')[4]
            cust_ProcessedIn2011('false')
            cust_ProcessedInTimeSheet('false')
            cust_Time LineT.tokenize(',')[2]
            cust_TransType LineT.tokenize(',')[3]
        }
    }
}
println(writer.toString())

def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}
//println(rawRecordMissedPIN)
println(rawRecordMissedPIN)