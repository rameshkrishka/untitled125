import java.text.DateFormat
import java.text.SimpleDateFormat


import java.util.TimeZone;

def a = new Date().toOffsetDateTime().plusHours(8)
println(a)
//def date = new Date()
//def dtFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
//def dt = date.format(dtFormat, TimeZone.getTimeZone('UTC+8'))
//assert dt instanceof String
//
//def newDate = Date.parse(dtFormat, dt)
//println(newDate)
//
//ZonedDateTime.parse (
//        "Mon Apr 03 16:49:56 PDT 2017" ,
//        DateTimeFormatter.ofPattern ( "EEE MMM dd HH:mm:ss z uuuu", Locale.US )
//)
//Instant result = Instant.parse("2021-01-08T09:36:29+08:00");
//System.out.println(result);
//yyyy-MM-dd HH:mm:ss.

//def a = dateTrans('041300','HHmmss','HHmmss+08:00')
//println(a)
//def dateTrans(String InDate, String InputFormat, String OutputFormat) {
// def dateStr = ''
// if (InDate.size() != 0) {
//  DateFormat srcDf = new SimpleDateFormat(InputFormat);
//  Date date = srcDf.parse(InDate)
//  def result = dateTime.withZone( DateTimeZone.forTimeZone(tz) ).toString();
//  println(date)
//  DateFormat destDf = new SimpleDateFormat(OutputFormat);
//  dateStr = destDf.format(date);
//  return dateStr
// } else {
//  return ''
// }
//}


//import groovy.xml.XmlUtil;
//import groovy.xml.StreamingMarkupBuilder;
//import groovy.xml.*;
//import groovy.xml.XmlUtil
//def xml             = new XmlParser().parse('C:/Users/i524259/Downloads/MM_ASN_FreightOrderDoc_test_output (3).xml')
//def nodes           = xml.'**'.findAll{it.name() && !it.text()}
//def removeNode      = { node ->
//    def parent      = node.parent()
//    parent.remove(node)
//}
//
//nodes.each{removeNode(it)}
//println groovy.xml.XmlUtil.serialize(xml)
//def val = '3'
//
//
//def a = '01000'
//
// a = a.size() >0 ?a.reverse().take(val.toInteger()).reverse() :""
//println(a)
//
//
//def  arg1= "UNLOC,CNSHA,BR,CN,Street"
//def arg2 = '7'
//
//w = arg1.tokenize(',')[arg2.toInteger()]
//println(w)
//
//arg1 = arg1.split(',').size()>arg2.toInteger()? arg1.split(',').getAt(arg2.toInteger()):''//.getAt(arg2.toInteger())
//println(arg1)

