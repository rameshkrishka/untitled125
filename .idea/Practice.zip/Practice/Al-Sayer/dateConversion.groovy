import java.text.SimpleDateFormat;
import java.text.DateFormat;
//def Date = dateTrans('2020-03-19T14:02:04.000',"yyyy-MM-dd'T'HH:mm:ss.S",'HH-mm-ss')
def Date = dateTrans('2',"H",'HH:mm')
println(Date)

def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        println(date.getClass())
        return dateStr
    } else {
        return ''
    }
}