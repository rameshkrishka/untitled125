import java.text.SimpleDateFormat;
import java.text.DateFormat;

def overTime = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/overtime/overtime.xml')
StringBuilder records = new StringBuilder()
overTime.cust_Overtime_ExtraHours_Request.each { r ->
    userId = r.externalCode.text()
    cust_startDate = r.cust_startDate.text()
    cust_endDate = r.cust_endDate.text()
    cust_beforeShiftHours = r.cust_beforeShiftHours.text()
    cust_duringShiftBreakHours = r.cust_duringShiftBreakHours.text()
    cust_afterShiftHours = r.cust_afterShiftHours.text()
    cust_extraHours = r.cust_extraHours.text()
    def cust_workingDays = r.cust_calendarDays.text() as Integer
    if (cust_beforeShiftHours != '0') {
        def countDate = 0
        cust_workingDays.times { w ->
            def startDate_externalCode = getDates(r.cust_startDate.text(), countDate)
            def startDate = dateTrans(startDate_externalCode,"yyyyMMdd",'yyyy-MM-dd')
            def sequnce = countDate + 1
            def externalCode = userId + '_' + startDate_externalCode + '_BSO'// + sequnce
            def startTime = '00:00:00'
            def hours = cust_beforeShiftHours.toString().split('\\.').getAt(0)
            def minutes = cust_beforeShiftHours.toString().split('\\.').size() >1 ? '0.'+cust_beforeShiftHours.toString().split('\\.').getAt(1):'00'
            minutes = minutes.toBigDecimal()*60
            cust_beforeShiftHours = hours+':'+minutes
            def endTime = dateTrans(cust_beforeShiftHours,"H:mm",'HH:mm:ss')
            def timeType = 'BSO'
            records.append(userId).append(',').append(startDate).append(',').append(externalCode).append(',').append(startTime)
                    .append(',').append(endTime).append(',').append(timeType).append('\n')
            countDate = countDate + 1
        }
    }
    if (cust_afterShiftHours != '0') {
        def countDate = 0
        cust_workingDays.times { w ->
            def startDate_externalCode = getDates(r.cust_startDate.text(), countDate)
            def startDate = dateTrans(startDate_externalCode,"yyyyMMdd",'yyyy-MM-dd')
            def sequnce = countDate + 1
            def externalCode =  userId + '_' + startDate_externalCode + '_ASO'// + sequnce
            def startTime = '00:00:00'
            def hours = cust_afterShiftHours.toString().split('\\.').getAt(0)
            def minutes = cust_afterShiftHours.toString().split('\\.').size() >1 ? '0.'+cust_afterShiftHours.toString().split('\\.').getAt(1):'00'
            minutes = minutes.toBigDecimal()*60
            cust_afterShiftHours = hours+':'+minutes
            def endTime = dateTrans(cust_afterShiftHours,"H:mm",'HH:mm:ss')
            def timeType = 'ASO'
            records.append(userId).append(',').append(startDate).append(',').append(externalCode).append(',').append(startTime)
                    .append(',').append(endTime).append(',').append(timeType).append('\n')
            countDate = countDate + 1
        }
    }
    if (cust_duringShiftBreakHours != '0') {
        def countDate = 0
        cust_workingDays.times { w ->
            def startDate_externalCode = getDates(r.cust_startDate.text(), countDate)
            def startDate = dateTrans(startDate_externalCode,"yyyyMMdd",'yyyy-MM-dd')
            def sequnce = countDate + 1
            def externalCode = userId + '_' + startDate_externalCode + '_DSO'// + sequnce
            def startTime = '00:00:00'
            def hours = cust_duringShiftBreakHours.toString().split('\\.').getAt(0)
            def minutes = cust_duringShiftBreakHours.toString().split('\\.').size() >1 ? '0.'+cust_duringShiftBreakHours.toString().split('\\.').getAt(1):'00'
            minutes = minutes.toBigDecimal()*60
            cust_duringShiftBreakHours = hours+':'+minutes
            def endTime = dateTrans(cust_duringShiftBreakHours,"H:mm",'HH:mm:ss')
            def timeType = 'DSO'
            records.append(userId).append(',').append(startDate).append(',').append(externalCode).append(',').append(startTime)
                    .append(',').append(endTime).append(',').append(timeType).append('\n')
            countDate = countDate + 1
        }
    }
    if (cust_extraHours != '0') {
        def countDate = 0
        cust_workingDays.times { w ->
            def startDate_externalCode = getDates(r.cust_startDate.text(), countDate)
            def startDate = dateTrans(startDate_externalCode,"yyyyMMdd",'yyyy-MM-dd')
            def sequnce = countDate + 1
            def externalCode = userId + '_' + startDate_externalCode + '_EHR'// + sequnce
            def startTime = '00:00:00'
            def hours = cust_extraHours.toString().split('\\.').getAt(0)
            def minutes = cust_extraHours.toString().split('\\.').size() >1 ? '0.'+cust_extraHours.toString().split('\\.').getAt(1):'00'
            minutes = minutes.toBigDecimal()*60
           cust_extraHours = hours+':'+minutes
            def endTime = dateTrans(cust_extraHours,"H:mm",'HH:mm:ss')
            def timeType = 'EHR'
            records.append(userId).append(',').append(startDate).append(',').append(externalCode).append(',').append(startTime)
                    .append(',').append(endTime).append(',').append(timeType).append('\n')
            countDate = countDate + 1
        }
    }

}
println(records)

def getDates(def startDate, Integer count) {
    DateFormat srcDf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
    Date Startdate = srcDf.parse(startDate)
    use(groovy.time.TimeCategory) {
        def duration = Startdate + count
        DateFormat destDf = new SimpleDateFormat('yyyyMMdd');
        dateStr = destDf.format(duration);
        return dateStr
    }
}
def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}