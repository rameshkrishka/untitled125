import java.text.DateFormat
import java.text.SimpleDateFormat
import groovy.xml.MarkupBuilder;

def records = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/OutPassRequestInfoType2002/cust_Official_Outpass_Request2.xml')

StringBuilder output = new StringBuilder()
records.cust_Official_Outpass_Request.each{ r->

    externalCode= r.externalCode
    startDate = dateTrans(r.cust_StartDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
    endDate = dateTrans(r.cust_EndDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
    getnumberOfDates = getDates(startDate,endDate)
    println(getnumberOfDates)
    sequenceDate = startDate
    reason = r.cust_Reason.text() =='3001'? '3015': r.cust_Reason.text()

    getnumberOfDates.eachLine { e->
        println(e)
    if (r.cust_StartTime.text() !=''){
        startTime = dateTrans(r.cust_StartTime.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(endDate).append(',').append(reason)
        .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime2.text() !=''){
        startTime = dateTrans(r.cust_StartTime2.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime2.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime3.text() !=''){
        startTime = dateTrans(r.cust_StartTime3.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime3.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime4.text() !=''){
        startTime = dateTrans(r.cust_StartTime4.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime4.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime5.text() !=''){
        startTime = dateTrans(r.cust_StartTime5.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime5.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime6.text() !=''){
        startTime = dateTrans(r.cust_StartTime6.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime6.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
    if (r.cust_StartTime7.text() !=''){
        startTime = dateTrans(r.cust_StartTime7.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        endTime =  dateTrans(r.cust_EndTime7.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
        output.append(externalCode).append(',').append(e).append(',').append(e).append(',').append(reason)
                .append(',').append(startTime).append(',').append(endTime).append('\n')
    }
//    if ((r.cust_StartDate.text() != r.cust_EndDate.text()) && (reason ='3010')){
//        output.append(externalCode).append(',').append(e).append(',').append(endDate).append(',').append(reason)
//                .append(',').append('').append(',').append('').append('\n')
//    }

}

}
println(output)

def writer = new StringWriter();
def builder = new MarkupBuilder(writer);
    builder.IT_TIME_DATE{
    output.eachLine { LineT ->
        item {
            EXTERNAL_CODE LineT.tokenize(',')[0]
            TIMETYPE LineT.tokenize(',')[3]
            USER_ID LineT.tokenize(',')[0]
            STARTTIME LineT.tokenize(',')[4]
            ENDTIME LineT.tokenize(',')[5]
            STARTDATE LineT.tokenize(',')[1]
            ENDDATE LineT.tokenize(',')[2]
            STATUS('APPROVED')
    }
    }
}
//}

println(writer.toString())


def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}

def getDates(def startDate, def endDate) {
    DateFormat srcDf = new SimpleDateFormat("yyyy-MM-dd");
    Date Startdate = srcDf.parse(startDate)
    DateFormat srceDf = new SimpleDateFormat("yyyy-MM-dd");
    Date enddate = srceDf.parse(endDate)
    formatter = new SimpleDateFormat("yyyy-MM-dd");
    StringBuilder numberOfDates = new StringBuilder()
//    def numberOfDays =''
    use(groovy.time.TimeCategory) {
        def duration=(enddate-Startdate).days
        for(int i=0;i<=duration;i++){
            numberOfDays = formatter.format(Startdate+i)
            numberOfDates.append(numberOfDays).append('\n')
        }
       return numberOfDates
    }
}