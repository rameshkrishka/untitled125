
import groovy.xml.XmlUtil;
import groovy.xml.StreamingMarkupBuilder;
import groovy.xml.*;

def rawRecords = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/xml/cust_Raw_Punch_Details.xml')
def validRecords = rawRecords.cust_Raw_Punch_Details.findAll{ it.cust_User.text() == '1801012'}

validRecords = validRecords.parent()

//println(parent.getClass())
//parent.remove(a)
def valid_data=XmlUtil.serialize(rawRecords)
//def deleted_data=XmlUtil.serialize(a);

println(valid_data)