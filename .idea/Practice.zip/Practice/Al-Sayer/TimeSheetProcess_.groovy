def records = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/CallActivity_9 (2).xml')
def person = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/xml/perPerson.xml')

def pinNumerMap =[:]
person.PerPerson.each{ p ->
    def userID = p.personId.text()
    def pinNumer = p.customString2.text()
    pinNumerMap.put(pinNumer,userID )
}



//def userID2 = pinNumerMap.get('102')
//println(userID2)
//println(pinNumerMap)
StringBuilder missedPunches = new StringBuilder()
def shiftStartTime = '08:00'
def BreakTime = '12:00'
def shiftEndTime = '17:00'
timeRecords = [:]
records.rows.each { r ->
//    println('hi')
    def timeRecordValue = []
    r.row.each { rc ->
        timeRecordKey = rc.PIN.text()
        ID = rc.ID.text()
       // ValueDate = rc.Date.text()
        ValueTransType = rc.TransType.text()
        Time = rc.Time.text()
        InsertionDateTime = rc.InsertionDateTime.text()
        def dateFormat = Date.parse("MM/dd/yyyy HH:mm", InsertionDateTime)
        def formattedDate = dateFormat.format("yyyy-MM-dd")
        def formattedHour = dateFormat.format("HH:mm:ss")
//        println(formattedDate)
//        println(formattedHour)
        def userID = pinNumerMap.get(timeRecordKey)
        //println(userID)
        value = userID+'|'+ID+'|'+ ValueTransType + '|' + formattedHour + '|' + formattedDate
        timeRecordValue.add(value)
        timeRecords.put(timeRecordKey, timeRecordValue)
    }
}
//println(timeRecords)

/****process Each day record ****/
timeRecords.each { tc ->
    def valueMap = tc.getValue()
    def keyMap = tc.getKey()
    Integer countPunchIn
    Integer countPunchOut
//    println(valueMap)
    valueMap.each { iv ->
        def transType = iv.toString().split('[|]').toList().get(2)
        if (transType == '7' && countPunchIn == null) {
            countPunchIn = 1
        } else if (transType == '7' && countPunchIn != null) {
            countPunchIn = countPunchIn + 1
        }
        if (transType == '8' && countPunchOut == null) {
            countPunchOut = 1
        } else if (transType == '8' && countPunchOut != null) {
            countPunchOut = countPunchOut + 1
        }
    }
    if (countPunchIn == countPunchOut) {
        println('valid')
    } else {
        Integer sequence = 0
        def pin = tc.getKey()
        def keyValue = tc.getValue()
//        println(keyValue)
        keyValue.each { adf ->

            def transTypeCode = adf.toString().split('[|]').getAt(2)
            if(transTypeCode == '8'|| transTypeCode == '7') {
                sequence = sequence + 1
                missedPunches.append(pin).append('|').append(adf).append('|').append(sequence).append('\n')
            }
        }
    }
//    println(countPunchIn)
//    println(countPunchOut)
//    println('-------')

}

println(missedPunches)

