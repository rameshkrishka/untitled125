import java.text.SimpleDateFormat;
import java.text.DateFormat;
def records = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/2002/sample_xml/new 374.xml')

def timeType = ['3000','3010','3015','3001','3015_BS','3015_AS']
StringBuilder output = new StringBuilder()
records.EmployeeTimeSheet.each{ et ->
    userId = et.userId.text()
    def approvalStatus = et.approvalStatus
    et.employeeTimeSheetEntry.EmployeeTimeSheetEntry.each{  ete ->
        if ( timeType.contains(ete.employeeTimeNav.EmployeeTime[0].timeType.text()) == true){
            def timeTypeCode =  ete.employeeTimeNav.EmployeeTime[0].timeType
            def startDate =  dateTrans(ete.employeeTimeNav.EmployeeTime[0].startDate.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'yyyy-MM-dd')
            def endDate =  dateTrans(ete.employeeTimeNav.EmployeeTime[0].endDate.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'yyyy-MM-dd')
            def quantityInHours = ete.employeeTimeNav.EmployeeTime[0].quantityInHours
            def startTime = dateTrans(ete.employeeTimeNav.EmployeeTime[0].startTime.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'HH:mm:ss')
            def endTime = ete.employeeTimeNav.EmployeeTime[0].endTime.text()
             endTime = dateTrans(ete.employeeTimeNav.EmployeeTime[0].endTime.text(),"yyyy-MM-dd'T'HH:mm:ss.S",'HH:mm:ss')
            def externalCode = ete.employeeTime
            output.append(userId).append(',').append(timeTypeCode).append(',').append(startDate).append(',').append(endDate).append(',').append(quantityInHours).append(',').append(startTime).append(',').append(endTime)
                    .append(',').append(externalCode).append(',').append(approvalStatus).append('\n')
        }
    }
}

println(output)

def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}