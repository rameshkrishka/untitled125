import java.text.SimpleDateFormat;
import java.text.DateFormat;
import static java.util.Calendar.*

//def shiftStartTimeFormat = Date.parse("HH:mm", shiftStartTime)
//def formattedDate = shiftStartTimeFormat.format("HH:mm", TimeZone.getTimeZone("IST"))
//shiftStartTimeFormat= Date.parse("HH:mm", formattedDate)

def shiftStartTime = "08:00"
def punchOut = "10:00"
def shiftEndTime = '17:00'
def checkIn = getTime('09:00')
def checkOut = getTime('10:00')
//def c =checkOut-checkIn.hours
println(checkIn)

def getTime(String inTime){
     def inTimeFormat = Date.parse("HH:mm", inTime)
     def formattedDate = inTimeFormat.format("HH:mm", TimeZone.getTimeZone("IST"))
     def inTimeConverted= Date.parse("HH:mm", formattedDate).toCalendar()
     return  inTimeConverted
}


//println(shiftStartTimeFormat.getClass())

//def c = nowDate1.get(nowDate1.HOUR)
//println(c)

//use (groovy.time.TimeCategory) {
//    println shiftStartTimeFormat-1.hours
//}
// Create date 10 November 2011.
//def cal = Calendar.getInstance(TimeZone.getTimeZone('IST'))
//def date = cal.time
//println(date)
//date.clearTime()
//date[YEAR] = 2011
//date[MONTH] = NOVEMBER
//date[DATE] = 10


//use (groovy.time.TimeCategory) {
//    def b = nowDate1
//    println(b)
//    // application on numbers:
//
//    def c =  1.minute.from.now
//    println(c.getClass())
////    println 10.hours.ago
////
////    // application on dates
////    def someDate = new Date()
////    println someDate - 3.months
//}
