import groovy.json.JsonSlurper

//.parse('C:/Users/i524259/Downloads/new 63.xml')
File sampleFile = new File('C:/Users/i524259/Downloads/sample.json')
def a = new JsonSlurper().parse(sampleFile)



a.enties.each{
    println(it.externalCode)
//    a.collect {(it.externalCode.text() == '123')}
}
println(a)

