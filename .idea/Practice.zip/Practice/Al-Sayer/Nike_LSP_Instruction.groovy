import javax.activation.MimeType
import java.text.DateFormat
import java.text.SimpleDateFormat
import groovy.xml.MarkupBuilder;
def brm_Reponse = new XmlSlurper().parse('C:/Users/i524259/Downloads/new 63.xml')
println(brm_Reponse)
def plantIDs                    = brm_Reponse.TradeTarget.Plant.text()//'1025,1027'
def execution_org_IDs           = brm_Reponse.TradeTarget.ExecutionOrganization.text()// 'Z055,Z035'
def Purchase_Order_type_IDs     = brm_Reponse.TradeTarget.POType.text()//"ZP20,ZP21"
def LADate_from                 = '-57'//brm_Reponse.TradeTarget.LA_Date_From.text()//'-2'
def LADate_to                   = '+1'//brm_Reponse.TradeTarget.LA_Date_To.text()//'+5'
def Query_Plant                 = plant(plantIDs)
def Query_execution_org         = execution_org(execution_org_IDs)
def Query_OrderType             = Purchase_Order_type(Purchase_Order_type_IDs)
def Query_LADate                = LADate(LADate_from,LADate_to)
def query                       = "\$filter=" + Query_Plant + " and " + Query_execution_org + " and " + Query_OrderType+ "and" +Query_LADate + ""
def filterQuery                 = java.net.URLEncoder.encode(query, "UTF-8")
println(Query_Plant)
println(Query_execution_org)
println(Query_OrderType)
println(Query_LADate)

println(query)

println(filterQuery)

fileName_CN     = 'CV_'+new Date().format("yyyy-MM-dd_a").replace("AM", "am").replace("PM","pm")+'_CN.csv'
fileName_CN_NBY = 'CV_'+new Date().format("yyyy-MM-dd_a").replace("AM", "am").replace("PM","pm")+'_CN_NBY.csv'
fileName_HK     = 'CV_'+new Date().format("yyyy-MM-dd_a").replace("AM", "am").replace("PM","pm")+'_HK.csv'
fileName_TW     = 'CV_'+new Date().format("yyyy-MM-dd_a").replace("AM", "am").replace("PM","pm")+'_TW.csv'

println(fileName_CN)
println(fileName_CN_NBY)
println(fileName_HK)
println(fileName_TW)

def LADate(String LADate_from,String LADate_to ) {
    def fromDate
    def toDate
    if (LADate_from.contains('-')) {
        fromDate = "(LADate ge datetime'" +new Date().minus(LADate_from.replaceAll("[^0-9]+","").toInteger()).format("yyyy-MM-dd") + "T00:00:00' and"
//        println('hi2')
    }
    if (LADate_to.contains('+')) {
        toDate = " LADate le datetime'" + new Date().plus(LADate_to.toInteger()).format("yyyy-MM-dd") + "T00:00:00')"
//        println('hi')
    }
    return fromDate + toDate
}




def plant(String strValue) {
    if (strValue != '') {
        def IDs = strValue.split(',')
        def formatted_IDs = ""
        for (int i = 0; i < IDs.size(); i++) {
            formatted_IDs = formatted_IDs + "Plant eq '" + IDs[i] + "' or "
        }
        formatted_IDs = "(" + formatted_IDs.reverse().drop(4).reverse() + ")"
        return formatted_IDs
    } else {
        def exceptionBody = "please maintain value for plant"
        throw new Exception(exceptionBody)
    }
}

def execution_org(String strValue) {
    if (strValue != '') {
        def IDs = strValue.split(',')
        def formatted_IDs = ""
        for (int i = 0; i < IDs.size(); i++) {
            formatted_IDs = formatted_IDs + "execution_org eq '" + IDs[i] + "' or "
        }
        formatted_IDs = "(" + formatted_IDs.reverse().drop(4).reverse() + ")"
        return formatted_IDs
    } else {
        def exceptionBody = "please maintain value for execution_org"
        throw new Exception(exceptionBody)
    }
}

def Purchase_Order_type(String strValue) {
    if (strValue != '') {
        def IDs = strValue.split(',')
        def formatted_IDs = ""
        for (int i = 0; i < IDs.size(); i++) {
            formatted_IDs = formatted_IDs + "Purchase_Order_type eq '" + IDs[i] + "' or "
        }
        formatted_IDs = "(" + formatted_IDs.reverse().drop(4).reverse() + ")"
        return formatted_IDs
    } else {
        def exceptionBody = "please maintain value for Purchase_Order_type"
        throw new Exception(exceptionBody)
    }
}

