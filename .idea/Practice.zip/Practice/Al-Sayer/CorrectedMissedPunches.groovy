import java.text.DateFormat
import java.text.SimpleDateFormat
import groovy.xml.MarkupBuilder;

def records = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/Corrected punches to timesheet/c5.xml')
StringBuilder output = new StringBuilder()
records.cust_Punch_Details.each { r ->
    userID = r.cust_Missed_Punch_Correction_externalCode
    startDate = dateTrans(r.cust_Missed_Punch_Correction_effectiveStartDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
    startT = dateTrans(r.cust_startTime_M.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
    endT = dateTrans(r.cust_endTime_M.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
    wsStartT = dateTrans(r.cust_Workschedule_StartTime.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
    wsEndT = dateTrans(r.cust_Workschedule_EndTime.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'HH:mm:ss')
    output = output.append(createTimeSlice(userID, startDate, startT, endT, wsStartT, wsEndT))

}


println(output.getClass())
StringBuilder seqOutput = new StringBuilder()
println(seqOutput)
def addSequence = [:]
output.toString().split('\n').sort().each { r ->
    def a = addSequence.get(r.tokenize(",")[0])
    if (a == null) {
        externaCode = r.tokenize(",")[1] + '_' +dateTrans(r.tokenize(",")[2].toString(), "yyyy-MM-dd", "ddMMyyyy") + '_1,' //r.tokenize(",")[2]//dateTrans(r.tokenize(",")[2], "yyyy-MM-dd", "ddMMyyyy")+ '_' + r.tokenize(",")[2] + '_1,'
        seqOutput.append(externaCode).append(r).append('\n')
        addSequence.put(r.tokenize(",")[0], 1)
    } else {
        def seqval = addSequence.get(r.tokenize(",")[0])
        def addSeq = seqval + 1
        externaCode = r.tokenize(",")[1] + '_' + dateTrans(r.tokenize(",")[2].toString(), "yyyy-MM-dd", "ddMMyyyy") + '_' + addSeq //r.tokenize(",")[2]//dateTrans(r.tokenize(",")[2], "yyyy-MM-dd", "ddMMyyyy")+ '_' + r.tokenize(",")[2] + '_1,'
        seqOutput.append(externaCode).append(',').append(r).append('\n')
        addSequence.put(r.tokenize(",")[0], addSeq)
    }
}
println(seqOutput)
def writer = new StringWriter();
def builder = new MarkupBuilder(writer);
builder.ExternalTimeData {
    seqOutput.eachLine { LineT ->
        ExternalTimeData {
            externalCode LineT.tokenize(',')[0]
            timeType LineT.tokenize(',')[4]
            userId LineT.tokenize(',')[2]
            startTime LineT.tokenize(',')[5]
            endTime LineT.tokenize(',')[6]
            startDate LineT.tokenize(',')[3]
        }
    }
}
println(writer.toString())

def createTimeSlice(def userID, def startDate, def startT, def endT, def wsStartT, def wsEndT) {
    StringBuilder out = new StringBuilder()
    if ((wsStartT == '' && wsEndT == '') || (wsStartT == '00:00:00' && wsEndT == '00:01:00')) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('BSH').append(',').append(startT).append(',').append(endT).append('\n')
    } else if (startT < wsStartT && wsEndT < endT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('BSH').append(',').append(startT).append(',').append(wsStartT).append('\n')
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('WORK').append(',').append(wsStartT).append(',').append(wsEndT).append('\n')
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('ASH').append(',').append(wsEndT).append(',').append(endT).append('\n')

    } else if (startT < wsStartT && endT > wsStartT && endT <= wsEndT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('BSH').append(',').append(startT).append(',').append(wsStartT).append('\n')
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('WORK').append(',').append(wsStartT).append(',').append(endT).append('\n')
    } else if (startT >= wsStartT && endT <= wsEndT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('WORK').append(',').append(startT).append(',').append(endT).append('\n')
    } else if (startT >= wsStartT && startT < wsEndT && endT > wsEndT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('WORK').append(',').append(startT).append(',').append(wsEndT).append('\n')
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('ASH').append(',').append(wsEndT).append(',').append(endT).append('\n')
    } else if (endT <= wsStartT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('BSH').append(',').append(startT).append(',').append(endT).append('\n')
    } else if (startT >= wsEndT) {
        externalCode = userID.toString() + startDate.replaceAll("[^0-9]+", "")
        out.append(externalCode).append(',').append(userID).append(',').append(startDate).append(',').append('ASH').append(',').append(startT).append(',').append(endT).append('\n')
    }
    return out
}


def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}
