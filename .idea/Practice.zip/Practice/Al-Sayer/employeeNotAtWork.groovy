import groovy.xml.MarkupBuilder

import java.text.DateFormat
import java.text.SimpleDateFormat

numberOfDeltaDate = '19'
sysDate = '07-10-2020'
sysDate = new SimpleDateFormat("dd-MM-yyyy").parse(sysDate)
//Date date = sysDate.minus(numberOfDeltaDate.toInteger())
Date date = sysDate.minus(numberOfDeltaDate.toInteger())

Date dateT = sysDate.minus(numberOfDeltaDate.toInteger()).plus(1)
println(date)
Calendar c = Calendar.getInstance();
c.setTime(dateT);
int dayOfWeek = c.get(Calendar.DAY_OF_WEEK) - c.getFirstDayOfWeek();
c.add(Calendar.DAY_OF_MONTH, -dayOfWeek);
Date weekStart = c.getTime();
c.add(Calendar.DAY_OF_MONTH, 6);
Date weekEnd = c.getTime();
println(sysDate)
println(weekStart)
outRundate = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy").parse(date.toString()).format("yyyy-MM-dd")+'T00:00:00.000'
outRundateEmployeeTime = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy").parse(date.toString()).format("yyyy-MM-dd")
outWeekStart =  new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy").parse(weekStart.toString()).previous().format("yyyy-MM-dd")
outWeekEnd = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy").parse(weekEnd.toString()).previous().format("yyyy-MM-dd")
def filterQuery = "&\$filter=startDate ge datetime'"+outWeekStart+"T00:00:00Z' and endDate le datetime'"+outWeekEnd+"T00:00:00Z' and (approvalStatus eq 'APPROVED' or approvalStatus eq 'PENDING' or approvalStatus eq 'PENDING_APPROVAL')"
def filterQueryemployeeTime =   "&\$filter=startDate eq datetime'"+outRundateEmployeeTime+"T00:00:00Z'"
println(filterQuery)
println(filterQueryemployeeTime)

def employeeTimeSheet = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/employeeNotAtWork/EmployeeTimeSheet_16Jun2020.xml')
def employeeTime = new XmlSlurper().parse('C:/Users/i524259/OneDrive - SAP SE/Projects/Al -Sayer/employeeNotAtWork/EmployeeTime_16Jun2020.xml')
employeeTimeSheetEntryMap = [:]
employeeTimeSheet.EmployeeTimeSheet.each{ ete ->
    userID = ete.userId.text()
    ete.employeeTimeSheetEntry.EmployeeTimeSheetEntry.each{ etse ->
        startDate = etse.startDate.text()
        employeeTimeSheetEntryMap.put(userID,startDate)
    }
}
//println(employeeTimeSheetEntryMap)

absence = ["1000", "1005", "1010", "1015", "1020", "1025", "1030", "1035", "1040", "1045", "1050", "1055", "2000", "2005", "2010", "2012", "3005" ]
StringBuilder entries =  new StringBuilder()
employeeTimeSheet.EmployeeTimeSheet.each{ ts ->
    userID = ts.userId.text()
    ts.employeeTimeValuationResult.EmployeeTimeValuationResult.each{ tvr ->
        if ( tvr.bookingDate == outRundate && tvr.payTypeName =='6075'){
            startDate =  dateTrans(tvr.bookingDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
            endDate = dateTrans(tvr.bookingDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
            timeType = 'NOTATWORK'
            approvalStatus = 'APPROVED'
            entries.append(userID).append(',').append(startDate).append(',').append(endDate).append(',').append(timeType).append(',').append(approvalStatus).append('\n')
        }
    }
}
employeeTime.EmployeeTime.each{ et ->
    if (absence.contains(et.timeType.text()) && et.approvalStatus.text() =='PENDING'&& et.quantityInDays.text().toBigDecimal() >=1) {
        userID = et.userId
        timeType = 'NOTATWORK'
        startDate =  dateTrans(et.startDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
        endDate = dateTrans(et.endDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
        approvalStatus= 'APPROVED'
        entries.append(userID).append(',').append(startDate).append(',').append(endDate).append(',').append(timeType).append(',').append(approvalStatus).append('\n')

    } else  if (absence.contains(et.timeType.text()) && et.approvalStatus.text() =='PENDING'&& et.quantityInDays.text().toBigDecimal() <1 && employeeTimeSheetEntryMap.get(et.userId.text()) == null){
        userID = et.userId
        timeType = 'NOTATWORK'
        startDate =  dateTrans(et.startDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
        endDate =  dateTrans(et.endDate.text(), "yyyy-MM-dd'T'HH:mm:ss.S", 'yyyy-MM-dd')
        approvalStatus= 'APPROVED'
        entries.append(userID).append(',').append(startDate).append(',').append(endDate).append(',').append(timeType).append(',').append(approvalStatus).append('\n')
    }
}
println(entries)



def writer = new StringWriter();
def builder = new MarkupBuilder(writer);
builder.EmployeeTime {
    entries.eachLine { LineT ->
        EmployeeTime {
            //externalCode LineT.tokenize(',')[0]
            timeType LineT.tokenize(',')[3]
            userId LineT.tokenize(',')[0]
            startDate LineT.tokenize(',')[1]
            endDate LineT.tokenize(',')[2]
            approvalStatus LineT.tokenize(',')[4]
        }
    }
}
//println(writer.toString())


def dateTrans(String InDate, String InputFormat, String OutputFormat) {
    def dateStr = ''
    if (InDate.size() != 0) {
        DateFormat srcDf = new SimpleDateFormat(InputFormat);
        Date date = srcDf.parse(InDate)
        DateFormat destDf = new SimpleDateFormat(OutputFormat);
        dateStr = destDf.format(date);
        return dateStr
    } else {
        return ''
    }
}
