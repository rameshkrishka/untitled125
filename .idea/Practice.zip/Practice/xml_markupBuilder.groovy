import groovy.xml.MarkupBuilder

def input = '''name,ID,position,costcenter,title,BU,status
A,1001,P1,123,25,A
B,1002,P2,1234,26,A
C,1003,,12345,27,T
D,1004,P4,123456,28,A'''

def input2 = '''name,ID,position,Status
Ramesh,1001,P1,A
ram,1002,P2,A
RameshK,1003,,T
Ramesh,1004,P4,A'''

def a =input.toString().split('\n').drop(1).join('\n')
def writer = new  StringWriter()
def line = new MarkupBuilder(writer)

line.root() {
    a.eachLine { r ->
        def splitRecord = r.split(',').toList()
        line.row {
            name(splitRecord[0])
            ID(splitRecord[1])
            position(splitRecord[2])
            costcenter(splitRecord[3])
            BU(splitRecord[4])
            status(splitRecord[5])

        }
    }
}

//records = new XmlSlurper().parseText(writer.toString())
println(writer)

//def c= writer.toString()
//println(c.getClass(java.lang.String))
//def list = new XmlSlurper().parse(c)
//     list.row.each{ s->
//         def name = s.name
//         println(name)
//
//     }


//def root = new MarkupBuilder()
////line.top(line)
//
//
//println(list)






//def root = new MarkupBuilder()
//root.root(){
//    empNo('1001')
//    root.row{
//        t1('value1')
//        t2('value2')
//        root.item{
//            its(name:'try')
//            it1('i1')
//            it2('i2')
//        }
//    }
//}
//
