import groovy.xml.MarkupBuilder
//
//def response=new XmlSlurper().parse("C:/Users/i524259/OneDrive - SAP SE/Practice/Sample XMl/test.xml")
//
//def xmlWriter = new StringWriter()
//def xmlMarkup = new MarkupBuilder(xmlWriter)
//
//xmlMarkup
//        .'x:movies'('xmlns:x': 'http://www.groovy-lang.org') {
//            'x:movie'(id: 1, 'the godfather')
//            'x:movie'(id: 2, 'ronin')
//        }
//
//def movies =
//        new XmlSlurper()
//                .parseText(xmlWriter.toString())
//                .declareNamespace(x: 'http://www.groovy-lang.org')
//
//println(xmlMarkup)


def writer = new StringWriter()
def xml = new MarkupBuilder(writer)

xml.records() {
    car(name: 'HSV Maloo', make: 'Holden', year: 2006) {
        country('Australia')
        record(type: 'speed', 'Production Pickup Truck with speed of 271kph')
    }
    car(name: 'Royale', make: 'Bugatti', year: 1931) {
        country('France')
        record(type: 'price', 'Most Valuable Car at $15 million')
    }
}
println(writer)
records = new XmlSlurper().parseText(writer.toString())
println(records)